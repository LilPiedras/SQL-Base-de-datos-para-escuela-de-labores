import tkinter as tk
import tkcalendar as tkc
import datetime
from tkcalendar import Calendar
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import customtkinter as ctk
from customtkinter import *
from tkinter import filedialog, simpledialog, colorchooser
from tkinter.scrolledtext import ScrolledText
import os
from docx import Document
from fpdf import FPDF
import PyPDF2

def abrir_appv2():
    Ventana_Principal.destroy()
    subprocess.Popen(["python", "appV2.py"])

def abrir_continuar():
    Ventana_Principal.destroy()
    subprocess.Popen(["python", "continuar.py"])

def reducir_alpha(img, nuevo_alpha):
    data = img.getdata()
    nueva_data = []
    for r, g, b, a in data:
        if a == 0:
            nueva_data.append((r, g, b, 0))
        else:
            nueva_data.append((r, g, b, nuevo_alpha))  
    img.putdata(nueva_data)
    return img

Ventana_Principal = tk.Tk()
Ventana_Principal.title("Doña Flor de Caminos")
Ventana_Principal.geometry("850x650")
Ventana_Principal.configure(bg="#E6D0F3")
Ventana_Principal.minsize(700,550)
Ventana_Principal.maxsize(950,800)
icono = tk.PhotoImage(file="imagenes/Logo.png")
Ventana_Principal.iconphoto(True, icono)
contenido_central = tk.Frame(Ventana_Principal, bg="#E6D0F3")
contenido_central.place(relx=0.5, rely=0.5, anchor="center")
original = Image.open("imagenes/Logo.png").convert("RGBA")
bbox = original.getbbox()
recortada = original.crop(bbox)
img_transparente = reducir_alpha(recortada, 150) 
img_tk = ImageTk.PhotoImage(img_transparente)
lbl_img = tk.Label(
    Ventana_Principal,
    image=img_tk,
    bg="#E6D0F3",
    borderwidth=0,
    highlightthickness=0
)
lbl_img.place(relx=0.6, rely=0.5, anchor='center')
titulinho = tk.Label(text="Escuela para el Emprendimiento", font= ("Times New Roman",16),bg="#E6D0F3")
titulinho.place(relx=0.44,rely=0)
titulinho2 = tk.Label(text="Doña Flor de Caminos",font=("Times New Roman",26),bg="#E6D0F3" )
titulinho2.place(relx=0.42,rely=0.05)
panel_izquierdo2 = tk.Frame(Ventana_Principal, bg="#A13AD1", width=210, height=850)
panel_izquierdo2.place(x=0, y=0)
panel_izquierdo = tk.Frame(Ventana_Principal, bg="#CFA5E2", width=200, height=850)
panel_izquierdo.place(x=0, y=0)
ctk.CTkButton(panel_izquierdo, text="Inicio de Sesión", height=50, width=175, fg_color="#E6D0F3", text_color="black", command=abrir_appv2).place(x=10, y=50)
ctk.CTkButton(panel_izquierdo, text="Registro de Usuario", height=50, width=175, fg_color="#E6D0F3", text_color="black", command=abrir_continuar).place(x=10, y=150)
Khezu = None 
def mostrar_calendario():
    global Khezu
    if Khezu is not None:
        return
    Khezu = tk.Frame(Ventana_Principal, bg="#CFA5E2", bd=2, relief="ridge")
    Khezu.place(relx=0.65, rely=0.1)
    Yian_Kut_Kut = Calendar(
        Khezu,
        selectmode='day',
        locale="es_ES",
        year=2025,
        month=5,
        day=5,
        date_pattern='y-mm-dd',
        font=("Arial", 9)
    )
    Yian_Kut_Kut.pack(padx=10, pady=10)
    btn_cerrar = tk.Button(
        Khezu,
        text="Cerrar calendario",
        command=ocultar_calendario,
        bg="#E6D0F3",
        fg="black",
        font=("Times New Roman", 9),
        relief="raised"
    )
    btn_cerrar.pack(pady=(0, 10))

def ocultar_calendario():
    global Khezu
    if Khezu:
        Khezu.destroy()
        Khezu = None

ctk.CTkButton(Ventana_Principal, text="Mostrar calendario", height=50, width=175, fg_color="#E6D0F3", text_color="black", command=mostrar_calendario).place(x=10,y=250)

# --- Bloc de Notas ---

class BlocDeNotas:
    def __init__(self, root):
        self.root = root
        self.root.title("Bloc de Notas")
        self.root.geometry("700x500")
        self.ruta = ""
        self.historial = []
        self.modo_oscuro = False
        self.color_fondo = "white"
        self.color_texto = "black"
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu_archivo = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Archivo", menu=self.menu_archivo)
        self.menu_archivo.add_command(label="Nuevo", command=self.nuevo)
        self.menu_archivo.add_command(label="Abrir", command=self.abrir)
        self.menu_archivo.add_command(label="Guardar", command=self.guardar)
        self.menu_archivo.add_command(label="Guardar como Word (.docx)", command=self.guardar_word)
        self.menu_archivo.add_command(label="Guardar como PDF (.pdf)", command=self.guardar_pdf)
        self.menu_archivo.add_separator()
        self.menu_archivo.add_command(label="Salir", command=self.salir)
        self.menu_historial = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Historial", menu=self.menu_historial)
        self.actualizar_historial_menu()
        self.menu_editar = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Editar", menu=self.menu_editar)
        self.menu_editar.add_command(label="Cortar", command=self.cortar)
        self.menu_editar.add_command(label="Copiar", command=self.copiar)
        self.menu_editar.add_command(label="Pegar", command=self.pegar)
        self.menu_editar.add_command(label="Borrar todo", command=self.borrar_todo)
        self.menu_insertar = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Insertar", menu=self.menu_insertar)
        self.menu_insertar.add_command(label="Imagen", command=self.insertar_imagen)
        self.menu_insertar.add_command(label="Video", command=self.insertar_video)
        self.menu_insertar.add_command(label="Documento", command=self.insertar_documento)
        self.menu_formato = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Formato", menu=self.menu_formato)
        self.menu_formato.add_command(label="Cambiar color de texto", command=self.cambiar_color_texto)
        self.menu_formato.add_command(label="Cambiar color de fondo", command=self.cambiar_color_fondo)
        self.menu_formato.add_separator()
        self.menu_formato.add_command(label="Modo oscuro", command=self.toggle_modo_oscuro)
        self.menu_bar.add_command(label="Recordatorio", command=self.crear_recordatorio)
        self.texto = ScrolledText(self.root, wrap=tk.WORD, bg=self.color_fondo, fg=self.color_texto)
        self.texto.pack(expand=True, fill="both")
        self.texto.image_refs = []

    def actualizar_historial_menu(self):
        self.menu_historial.delete(0, tk.END)
        if not self.historial:
            self.menu_historial.add_command(label="Sin historial", state="disabled")
        else:
            for ruta in self.historial[-10:][::-1]:
                self.menu_historial.add_command(
                    label=os.path.basename(ruta),
                    command=lambda r=ruta: self.abrir_archivo_historial(r)
                )

    def abrir_archivo_historial(self, ruta):
        if os.path.exists(ruta):
            ext = os.path.splitext(ruta)[1].lower()
            try:
                if ext == ".txt":
                    with open(ruta, "r", encoding="utf-8") as archivo:
                        contenido = archivo.read()
                elif ext == ".docx":
                    contenido = self.leer_docx(ruta)
                elif ext == ".pdf":
                    contenido = self.leer_pdf(ruta)
                else:
                    messagebox.showwarning("Formato no soportado", "Solo se pueden abrir archivos .txt, .docx y .pdf desde el historial.")
                    return
                self.texto.delete(1.0, tk.END)
                self.texto.insert(tk.END, contenido)
                self.ruta = ruta
                self.root.title(f"Bloc de Notas - {self.ruta}")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{e}")
        else:
            messagebox.showerror("Error", "El archivo no existe.")

    def leer_docx(self, ruta):
        doc = Document(ruta)
        texto = []
        for para in doc.paragraphs:
            texto.append(para.text)
        return "\n".join(texto)

    def leer_pdf(self, ruta):
        texto = ""
        with open(ruta, "rb") as f:
            lector = PyPDF2.PdfReader(f)
            for pagina in lector.pages:
                texto += pagina.extract_text() + "\n"
        return texto

    def guardar_word(self):
        ruta_guardar = filedialog.asksaveasfilename(
            defaultextension=".docx",
            filetypes=[("Documentos Word", "*.docx")]
        )
        if ruta_guardar:
            try:
                doc = Document()
                texto = self.texto.get(1.0, tk.END).strip()
                for linea in texto.split("\n"):
                    doc.add_paragraph(linea)
                doc.save(ruta_guardar)
                self.ruta = ruta_guardar
                self.root.title(f"Bloc de Notas - {self.ruta}")
                if self.ruta not in self.historial:
                    self.historial.append(self.ruta)
                    self.actualizar_historial_menu()
                messagebox.showinfo("Guardado", "Archivo guardado como Word correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo guardar el archivo Word:\n{e}")

    def guardar_pdf(self):
        ruta_guardar = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("Archivos PDF", "*.pdf")]
        )
        if ruta_guardar:
            try:
                pdf = FPDF()
                pdf.add_page()
                pdf.set_auto_page_break(auto=True, margin=15)
                pdf.set_font("Arial", size=12)
                texto = self.texto.get(1.0, tk.END).strip()
                for linea in texto.split("\n"):
                    pdf.cell(0, 10, txt=linea, ln=True)
                pdf.output(ruta_guardar)
                self.ruta = ruta_guardar
                self.root.title(f"Bloc de Notas - {self.ruta}")
                if self.ruta not in self.historial:
                    self.historial.append(self.ruta)
                    self.actualizar_historial_menu()
                messagebox.showinfo("Guardado", "Archivo guardado como PDF correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo guardar el archivo PDF:\n{e}")

    def abrir(self):
        archivo = filedialog.askopenfile(mode="rb", filetypes=[("Archivos de texto y documentos", "*.txt;*.docx;*.pdf")])
        if archivo:
            ruta = archivo.name
            ext = os.path.splitext(ruta)[1].lower()
            try:
                if ext == ".txt":
                    contenido = archivo.read().decode("utf-8")
                elif ext == ".docx":
                    archivo.close()
                    contenido = self.leer_docx(ruta)
                elif ext == ".pdf":
                    archivo.close()
                    contenido = self.leer_pdf(ruta)
                else:
                    messagebox.showwarning("Formato no soportado", "Solo se pueden abrir archivos .txt, .docx y .pdf")
                    return
                self.texto.delete(1.0, tk.END)
                self.texto.insert(tk.END, contenido)
                self.ruta = ruta
                self.root.title(f"Bloc de Notas - {self.ruta}")
                if self.ruta not in self.historial:
                    self.historial.append(self.ruta)
                    self.actualizar_historial_menu()
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{e}")

    def cambiar_color_texto(self):
        color = colorchooser.askcolor(title="Seleccione color de texto")
        if color[1]:
            self.color_texto = color[1]
            self.texto.config(fg=self.color_texto)

    def cambiar_color_fondo(self):
        color = colorchooser.askcolor(title="Seleccione color de fondo")
        if color[1]:
            self.color_fondo = color[1]
            self.texto.config(bg=self.color_fondo)

    def toggle_modo_oscuro(self):
        if not self.modo_oscuro:
            self.color_fondo = "#2e2e2e"
            self.color_texto = "#dcdcdc"
            self.modo_oscuro = True
        else:
            self.color_fondo = "white"
            self.color_texto = "black"
            self.modo_oscuro = False
        self.texto.config(bg=self.color_fondo, fg=self.color_texto)

    import datetime


    def crear_recordatorio(self):
        hora = simpledialog.askstring("Recordatorio", "Hora para recordar (HH:MM):")
        periodo = simpledialog.askstring("Recordatorio", "¿AM o PM?").strip().upper()

        mensaje = simpledialog.askstring("Recordatorio", "Mensaje del recordatorio:")
    
        if hora and mensaje and periodo in ["AM", "PM"]:
            try:
          
                hora_obj = datetime.datetime.strptime(hora, "%I:%M")
            
            
                if periodo == "PM" and hora_obj.hour != 12:
                    hora_obj = hora_obj.replace(hour=hora_obj.hour + 12)
                elif periodo == "AM" and hora_obj.hour == 12:
                    hora_obj = hora_obj.replace(hour=0)

                ahora = datetime.datetime.now()
                recordatorio = ahora.replace(hour=hora_obj.hour, minute=hora_obj.minute, second=0, microsecond=0)
            
            
                if recordatorio < ahora:
                    recordatorio += datetime.timedelta(days=1)

                ms_espera = int((recordatorio - ahora).total_seconds() * 1000)
                self.root.after(ms_espera, lambda: messagebox.showinfo("Recordatorio", mensaje))

                messagebox.showinfo("Recordatorio", f"Recordatorio programado para las {hora} {periodo}.")
            except Exception as e:
                messagebox.showerror("Error", "Formato de hora incorrecto. Use HH:MM y seleccione AM o PM.")
        else:
            messagebox.showerror("Error", "Debe ingresar hora, AM/PM y mensaje.")


    def insertar_imagen(self):
        ruta_img = filedialog.askopenfilename(filetypes=[("Imágenes", "*.png;*.jpg;*.jpeg;*.gif;*.bmp")])
        if ruta_img:
            try:
                img = Image.open(ruta_img)
                img.thumbnail((300, 300))
                img_tk = ImageTk.PhotoImage(img)
                self.texto.image_create(tk.END, image=img_tk)
                self.texto.insert(tk.END, "\n")
                self.texto.image_refs.append(img_tk)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo cargar la imagen:\n{e}")

    def insertar_video(self):
        ruta_video = filedialog.askopenfilename(filetypes=[("Videos", "*.mp4;*.avi;*.mov;*.wmv;*.mkv")])
        if ruta_video:
            nombre = os.path.basename(ruta_video)
            self.texto.insert(tk.END, f"[Video: {nombre}]\n")
            self.texto.tag_add(nombre, "end-2l linestart", "end-1l lineend")
            self.texto.tag_bind(nombre, "<Button-1>", lambda e, r=ruta_video: self.abrir_archivo(r))
            self.texto.tag_config(nombre, foreground="blue", underline=1)

    def insertar_documento(self):
        ruta_doc = filedialog.askopenfilename(filetypes=[("Documentos", "*.pdf;*.docx;*.xlsx;*.pptx;*.txt")])
        if ruta_doc:
            nombre = os.path.basename(ruta_doc)
            self.texto.insert(tk.END, f"[Documento: {nombre}]\n")
            self.texto.tag_add(nombre, "end-2l linestart", "end-1l lineend")
            self.texto.tag_bind(nombre, "<Button-1>", lambda e, r=ruta_doc: self.abrir_archivo(r))
            self.texto.tag_config(nombre, foreground="green", underline=1)

    def abrir_archivo(self, ruta):
        try:
            if os.name == "nt":
                os.startfile(ruta)
            elif os.name == "posix":
                subprocess.call(("xdg-open", ruta))
            else:
                messagebox.showinfo("Abrir archivo", f"Ruta: {ruta}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{e}")

    def nuevo(self):
        self.texto.delete(1.0, tk.END)
        self.ruta = ""
        self.root.title("Bloc de Notas - Nuevo archivo")

    def guardar(self):
        if not self.ruta:
            archivo = filedialog.asksaveasfile(
                mode="w",
                defaultextension=".txt",
                filetypes=[("Archivos de texto", "*.txt")]
            )
            if archivo:
                self.ruta = archivo.name
                archivo.write(self.texto.get(1.0, tk.END))
                archivo.close()
                self.root.title(f"Bloc de Notas - {self.ruta}")
                if self.ruta not in self.historial:
                    self.historial.append(self.ruta)
                    self.actualizar_historial_menu()
        else:
            with open(self.ruta, "w", encoding="utf-8") as archivo:
                archivo.write(self.texto.get(1.0, tk.END))
            if self.ruta not in self.historial:
                self.historial.append(self.ruta)
                self.actualizar_historial_menu()

    def salir(self):
        if messagebox.askokcancel("Salir", "¿Desea salir del bloc de notas?"):
            self.root.destroy()

    def cortar(self):
        self.texto.event_generate("<<Cut>>")

    def copiar(self):
        self.texto.event_generate("<<Copy>>")

    def pegar(self):
        self.texto.event_generate("<<Paste>>")

    def borrar_todo(self):
        self.texto.delete(1.0, tk.END)

def abrir_bloc_notas():
    ventana_bloc = tk.Toplevel(Ventana_Principal)
    ventana_bloc.title("Bloc de Notas")
    app = BlocDeNotas(ventana_bloc)
    ventana_bloc.grab_set()


ctk.CTkButton(panel_izquierdo, text="Bloc de Notas", height=50, width=175, fg_color="#E6D0F3", text_color="black", command=abrir_bloc_notas).place(x=10, y=350)

Ventana_Principal.mainloop()


