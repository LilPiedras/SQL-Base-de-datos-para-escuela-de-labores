-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2025 at 06:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `escuela`
--

-- --------------------------------------------------------

--
-- Table structure for table `asistencia_docentes`
--

CREATE TABLE `asistencia_docentes` (
  `id_asis` int(11) NOT NULL,
  `ci_docente` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `presente` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `asistencia_docentes`
--

INSERT INTO `asistencia_docentes` (`id_asis`, `ci_docente`, `fecha`, `presente`) VALUES
(1, 11495705, '2025-05-01', 1),
(2, 11495705, '2025-05-02', 0),
(3, 11495705, '2025-05-03', 1),
(4, 11495705, '2025-05-04', 0),
(5, 11495705, '2025-05-05', 1),
(6, 10162664, '2025-05-01', 1),
(7, 10162664, '2025-05-02', 1),
(8, 10162664, '2025-05-03', 1),
(9, 10162664, '2025-05-04', 1),
(10, 10162664, '2025-05-05', 1),
(11, 11024208, '2025-05-01', 1),
(12, 11024208, '2025-05-02', 0),
(13, 11024208, '2025-05-03', 1),
(14, 11024208, '2025-05-04', 0),
(15, 11024208, '2025-05-05', 1),
(16, 4628889, '2025-05-01', 1),
(17, 4628889, '2025-05-02', 1),
(18, 4628889, '2025-05-03', 1),
(19, 4628889, '2025-05-04', 1),
(20, 4628889, '2025-05-05', 1),
(22, 11495705, '2025-06-24', 1),
(23, 9232949, '2025-06-26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `asistencia_estudiantes`
--

CREATE TABLE `asistencia_estudiantes` (
  `id_asis_estu` int(11) NOT NULL,
  `ci_estu` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `asis` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cursos`
--

CREATE TABLE `cursos` (
  `idcursos` int(11) NOT NULL,
  `nom_cur` varchar(50) DEFAULT NULL,
  `docente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cursos`
--

INSERT INTO `cursos` (`idcursos`, `nom_cur`, `docente`) VALUES
(1, 'Barberia', 4628889),
(2, 'Bordado y Tejido', 9218226),
(3, 'Ceramica', 10162664),
(4, 'Corte y Confección', 5891424),
(5, 'Floristeria', 11024208),
(6, 'Manualidades', 9232949),
(7, 'Peliqueria', 23143019),
(8, 'Pintura', 11495705),
(9, 'Gastronomia', 5657503),
(10, 'Reposteria', 13148661);

-- --------------------------------------------------------

--
-- Table structure for table `docentes`
--

CREATE TABLE `docentes` (
  `Ci` int(8) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `tele` int(11) DEFAULT NULL,
  `cursos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `docentes`
--

INSERT INTO `docentes` (`Ci`, `nombre`, `apellido`, `tele`, `cursos`) VALUES
(4628889, 'Gladys', 'Labrador', 2147483647, 7),
(5657503, 'Ernestina', 'Rico', 2147483647, 9),
(5891424, 'Yoly', 'Noroño', 2147483647, 4),
(9218226, 'Susana', 'Escalante', 2147483647, 3),
(9232949, 'Magaly', 'Vivas', 2147483647, 6),
(10162664, 'Norma', 'Diaz', 2147483647, 2),
(11024208, 'Karina', 'Mendoza', 2147483647, 5),
(11495705, 'Elisabel', 'Mora', 2147483647, 8),
(13148661, 'Carolina', 'Montilla', 424717879, 10),
(23143019, 'Marina', 'Palacio', 2147483647, 1);

-- --------------------------------------------------------

--
-- Table structure for table `estudiantes`
--

CREATE TABLE `estudiantes` (
  `cedula` int(8) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `tele` varchar(20) DEFAULT NULL,
  `id_curso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `estudiantes`
--

INSERT INTO `estudiantes` (`cedula`, `nombre`, `apellido`, `tele`, `id_curso`) VALUES
(23442, 'Yoshe', 'Gutierrezzz', '0423322413', 4),
(123123, 'Chepe', 'Medin', '412060000', 1),
(9463212, 'Fred', 'Juarez', '2147483647', 2),
(10233451, 'Aria', 'Labrador', '04123458976', 5),
(12455678, 'Victor', 'Vasquez', '04145674311', 8),
(19456781, 'Juja', 'Lag', '02774563412', 10),
(20456843, 'Kelly', 'Monsalve', '0147483647', 9),
(31132645, 'Wilson jr', 'Carvajal', '04123451210', 5),
(31680951, 'Alejandro', 'Sanchez', '2147483647', 5);

-- --------------------------------------------------------

--
-- Table structure for table `notas`
--

CREATE TABLE `notas` (
  `idnotazzzz` int(11) NOT NULL,
  `nota1` int(2) DEFAULT NULL,
  `nota2` int(2) DEFAULT NULL,
  `nota3` int(2) DEFAULT NULL,
  `notadefinitiva` int(2) DEFAULT NULL,
  `estudiante` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notas`
--

INSERT INTO `notas` (`idnotazzzz`, `nota1`, `nota2`, `nota3`, `notadefinitiva`, `estudiante`) VALUES
(2, 5, 5, 10, 7, 31680951),
(3, 13, 4, 20, 12, 123123);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `contrasena` varchar(255) DEFAULT NULL,
  `clave` int(4) DEFAULT NULL,
  `rol` varchar(20) DEFAULT 'docente',
  `ci_docente` int(8) DEFAULT NULL,
  `curso` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `contrasena`, `clave`, `rol`, `ci_docente`, `curso`) VALUES
(101, 'Magaly', 'Vivas', '12345', 1234, 'admin', 9232949, NULL),
(102, 'Elisabel', 'Mora', 'em1215', NULL, 'docente', 11495705, NULL),
(103, 'Yoly', 'Noroño', 'yol1N33', NULL, 'docente', 5891424, NULL),
(104, 'Karina', 'Mendoza', 'ET333', NULL, 'docente', 11024208, NULL),
(105, 'Susana', 'Escalante', 'Mortadela', NULL, 'docente', 9218226, NULL),
(106, 'Gladys', 'Labrador', '56789', NULL, 'docente', 4628889, NULL),
(107, 'Ernestina', 'Rico', '1111', NULL, 'docente', 5657503, NULL),
(108, 'Carolina', 'Montilla', 'C@rol1', NULL, 'docente', 13148661, NULL),
(109, 'Marina', 'Palacio', 'M4rina_', NULL, 'docente', 23143019, NULL),
(110, 'Norma', 'Diaz', 'Momozzz', NULL, 'docente', 10162664, NULL),
(111, 'Jesus', 'Pineda', 'SuperVisor', NULL, 'su', NULL, NULL),
(112, 'Franklin', 'Quintero', '0526', NULL, 'SuperADMIN', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asistencia_docentes`
--
ALTER TABLE `asistencia_docentes`
  ADD PRIMARY KEY (`id_asis`),
  ADD KEY `ci_docente` (`ci_docente`);

--
-- Indexes for table `asistencia_estudiantes`
--
ALTER TABLE `asistencia_estudiantes`
  ADD PRIMARY KEY (`id_asis_estu`),
  ADD KEY `ci_estu` (`ci_estu`);

--
-- Indexes for table `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`idcursos`),
  ADD KEY `fk_docente` (`docente`);

--
-- Indexes for table `docentes`
--
ALTER TABLE `docentes`
  ADD PRIMARY KEY (`Ci`),
  ADD KEY `fk_curso_docentes` (`cursos`);

--
-- Indexes for table `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`cedula`),
  ADD KEY `fk_estudiantes_curso` (`id_curso`);

--
-- Indexes for table `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`idnotazzzz`),
  ADD KEY `fk_notas_estudiante` (`estudiante`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ci_docente` (`ci_docente`),
  ADD KEY `fk_curso` (`curso`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `asistencia_docentes`
--
ALTER TABLE `asistencia_docentes`
  MODIFY `id_asis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `asistencia_estudiantes`
--
ALTER TABLE `asistencia_estudiantes`
  MODIFY `id_asis_estu` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cursos`
--
ALTER TABLE `cursos`
  MODIFY `idcursos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=510;

--
-- AUTO_INCREMENT for table `notas`
--
ALTER TABLE `notas`
  MODIFY `idnotazzzz` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `asistencia_docentes`
--
ALTER TABLE `asistencia_docentes`
  ADD CONSTRAINT `asistencia_docentes_ibfk_1` FOREIGN KEY (`ci_docente`) REFERENCES `docentes` (`Ci`);

--
-- Constraints for table `asistencia_estudiantes`
--
ALTER TABLE `asistencia_estudiantes`
  ADD CONSTRAINT `asistencia_estudiantes_ibfk_1` FOREIGN KEY (`ci_estu`) REFERENCES `estudiantes` (`cedula`);

--
-- Constraints for table `cursos`
--
ALTER TABLE `cursos`
  ADD CONSTRAINT `fk_docente` FOREIGN KEY (`docente`) REFERENCES `docentes` (`Ci`);

--
-- Constraints for table `docentes`
--
ALTER TABLE `docentes`
  ADD CONSTRAINT `fk_curso_docentes` FOREIGN KEY (`cursos`) REFERENCES `cursos` (`idcursos`);

--
-- Constraints for table `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD CONSTRAINT `fk_estudiantes_curso` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`idcursos`);

--
-- Constraints for table `notas`
--
ALTER TABLE `notas`
  ADD CONSTRAINT `fk_notas_estudiante` FOREIGN KEY (`estudiante`) REFERENCES `estudiantes` (`cedula`);

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_ci_docente` FOREIGN KEY (`ci_docente`) REFERENCES `docentes` (`Ci`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_curso` FOREIGN KEY (`curso`) REFERENCES `cursos` (`idcursos`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
