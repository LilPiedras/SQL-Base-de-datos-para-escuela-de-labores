import mysql.connector

class Docentes:

    def __init__(self):
        self.cnn = mysql.connector.connect(host="localhost", user="root", password="", database="escuela")

    def __str__(self):
        datos = self.consulta_docentes()
        aux = ""
        for row in datos:
            aux += str(row) + "\n"
        return aux

    def consulta_director(self):
        cur = self.cnn.cursor()
        cur.execute("SELECT * FROM usuarios WHERE rol = 'admin'")
        datos = cur.fetchall()
        cur.close()
        return datos

    def buscar_docentes(self, Ci):
        cur = self.cnn.cursor()
        sql = "SELECT * FROM usuarios WHERE ci_docente = %s"
        cur.execute(sql, (Ci,))
        datos = cur.fetchone()
        cur.close()
        return datos

    def modificar_estudiantes(self, ci, nombre, apellido, telefono):
        cursor = self.cnn.cursor()

        # Actualiza el usuario con rol director
        sql_usuario = "UPDATE usuarios SET nombre=%s, apellido=%s, contrasena=%s WHERE id=%s"
        cursor.execute(sql_usuario, (nombre, apellido, telefono, ci))

        self.cnn.commit()
        cursor.close()

