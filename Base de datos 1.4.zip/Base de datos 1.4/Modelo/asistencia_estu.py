import mysql.connector
from datetime import date

class Asistencia_Estudiantes:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="escuela"
        )
        self.cursor = self.conn.cursor()

    # Registra asistencia del día a día para un docente
    def registrar_asistencia(self, ci_estu, asis):
        sql = """
            INSERT INTO asistencia_estudiantes (ci_estu, fecha, asis)
            VALUES (%s, %s, %s)
        """
        valores = (ci_estu, date.today(), asis)
        self.cursor.execute(sql, valores)
        self.conn.commit()

    # Consulta asistencias para un mes y año dados
    def obtener_asistencia_mes(self, mes, anio):
        sql = """
            SELECT ci_estu, fecha, asis
            FROM asistencia_estudiantes
            WHERE MONTH(fecha) = %s AND YEAR(fecha) = %s
            ORDER BY fecha
        """
        self.cursor.execute(sql, (mes, anio))
        return self.cursor.fetchall()

    # Consulta asistencias para un docente en especificio y su mes o/y año
    def obtener_asistencia_por_docente(self, ci_estu, mes, anio):
        sql = """
            SELECT fecha, asis
            FROM asistencia_estudiantes
            WHERE ci_estu = %s AND MONTH(fecha) = %s AND YEAR(fecha) = %s
            ORDER BY fecha
        """
        self.cursor.execute(sql, (ci_estu, mes, anio))
        return self.cursor.fetchall()