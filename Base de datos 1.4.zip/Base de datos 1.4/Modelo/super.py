import mysql.connector

class Supervisor:

    def __init__(self):
        self.cnn = mysql.connector.connect(host="localhost", user="root", password="", database="escuela")

    def __str__(self):
        datos = self.consulta_docentes()
        aux = ""
        for row in datos:
            aux += str(row) + "\n"
        return aux

    def obtener_cursos(self):
        cur = self.cnn.cursor()
        cur.execute("SELECT idcursos, nom_cur FROM cursos")
        cursos = cur.fetchall()
        cur.close()
        return cursos

    def consulta_supervisor(self):
        cur = self.cnn.cursor()
        sql = "SELECT * FROM usuarios WHERE rol = 'su'"
        cur.execute(sql)
        datos = cur.fetchall()
        cur.close()
        return datos

    def buscar_docentes(self, Ci):
        cur = self.cnn.cursor()
        sql = "SELECT * FROM docentes WHERE Ci = %s"
        cur.execute(sql, (Ci,))
        datos = cur.fetchone()
        cur.close()
        return datos

    def insertar_estudiante(self, ci, nombre, apellido, telefono, cursos):
        cur = self.cnn.cursor()
        sql = "INSERT INTO docentes (Ci, nombre, apellido, tele, cursos) VALUES (%s, %s, %s, %s, %s)"
        cur.execute(sql, (ci, nombre, apellido, telefono, cursos))
        self.cnn.commit()
        cur.close()
        return cur.rowcount

    def eliminar_estudiante(self, Ci):
        cur = self.cnn.cursor()
        sql = "DELETE FROM docentes WHERE Ci = %s"
        cur.execute(sql, (Ci,))
        n = cur.rowcount
        self.cnn.commit()
        cur.close()
        return n

    def modificar_estudiantes(self, ci, nombre, apellido, telefono, cursos):
        cursor = self.cnn.cursor()

        # Actualiza la tabla docentes
        sql_docente = "UPDATE docentes SET nombre=%s, apellido=%s, tele=%s, cursos=%s WHERE Ci=%s"
        cursor.execute(sql_docente, (nombre, apellido, telefono, cursos, ci))

        # Actualiza también la tabla usuarios si existe ese docente allí
        sql_usuario = "UPDATE usuarios SET nombre=%s, apellido=%s WHERE ci_docente=%s"
        cursor.execute(sql_usuario, (nombre, apellido, ci))

        self.cnn.commit()
        cursor.close()