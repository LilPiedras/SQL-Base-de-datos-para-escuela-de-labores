import mysql.connector

class Usuarios:

    def __init__(self):
        self.cnn = mysql.connector.connect(host="localhost", user="root", password="", database="escuela")

    def __str__(self):
        datos = self.consulta_usuarios()
        aux = ""
        for row in datos:
            aux = aux + str(row) + "\n"
        return aux

    def consulta_usuarios(self):
        cur = self.cnn.cursor()
        # Solo id, nombre, apellido y clave (contraseña)
        cur.execute("SELECT id, nombre, apellido, contrasena, rol FROM usuarios")
        datos = cur.fetchall()
        cur.close()
        return datos

    def buscar_usuarios(self, id):
        cur = self.cnn.cursor()
        sql = "SELECT id, nombre, apellido, contrasena, rol FROM usuarios WHERE id = %s"
        cur.execute(sql, (id,))
        datos = cur.fetchone()
        cur.close()
        return datos

    def insertar_usuario(self, id, nombre, apellido, contrasena, rol):
        cur = self.cnn.cursor()
        sql = "INSERT INTO usuarios (id, nombre, apellido, contrasena, rol) VALUES (%s, %s, %s, %s, %s)"
        cur.execute(sql, (id, nombre, apellido, contrasena))
        self.cnn.commit()
        cur.close()
        return cur.rowcount

    def eliminar_usuario(self, id_):
        cur = self.cnn.cursor()
        sql = "DELETE FROM usuarios WHERE id = %s"
        cur.execute(sql, (id,))
        n = cur.rowcount
        self.cnn.commit()
        cur.close()
        return n

    def modificar_usuarios(self, id, nombre, apellido, contrasena, rol):
        print(f"Modificando usuario {id} con datos: {nombre}, {apellido}, {contrasena}, {rol}")
        cur = self.cnn.cursor()
        sql = "UPDATE usuarios SET nombre = %s, apellido = %s, contrasena = %s, rol = %s WHERE id = %s"
        cur.execute(sql, (nombre, apellido, contrasena, rol, id))
        self.cnn.commit()
        n = cur.rowcount
        cur.close()
        return n
