import mysql.connector


class Estudiantes:

    def __init__(self):
        self.cnn = mysql.connector.connect(host="localhost", user="root", password="", database="escuela")

    def __str__(self):
        datos = self.consulta_estudiantes()
        aux = ""
        for row in datos:
            aux= aux + str(row) + "\n"  #Para recorrer los datos 
        return aux

    def consulta_estudiantes(self):
        cur = self.cnn.cursor()
        cur.execute("SELECT cedula, nombre, apellido, tele, id_curso FROM estudiantes")
        datos = cur.fetchall()
        cur.close()
        return datos



    def buscar_estudiantes(self, cedula):
        cur = self.cnn.cursor()
        sql = "SELECT * FROM estudiantes WHERE cedula = {}".format(cedula)
        cur.execute(sql)
        datos = cur.fetchone()
        cur.close()
        return datos

    def insertar_estudiante(self, nombre, apellido, cedula, tele, curso):
        cur = self.cnn.cursor()
        sql = "INSERT INTO estudiantes (nombre, apellido, cedula, tele, id_curso) VALUES (%s, %s, %s, %s, %s)"
        cur.execute(sql, (nombre, apellido, cedula, tele, curso))
        self.cnn.commit()  # Confirmar cambios
        cur.close()
        return cur.rowcount  # Retorna cuántas filas fueron afectadas

    def eliminar_estudiante(self, cedula):
        cur = self.cnn.cursor()
        sql = "DELETE FROM estudiantes WHERE cedula = %s"
        cur.execute(sql,(cedula,))
        n = cur.rowcount
        self.cnn.commit()
        cur.close()
        return n

    def modificar_estudiantes(self, nombre, apellido, tele, curso, cedula):
        cur = self.cnn.cursor()
        sql = "UPDATE estudiantes SET nombre = %s, apellido = %s, tele = %s, id_curso = %s WHERE cedula = %s"
        cur.execute(sql, (nombre, apellido, tele, curso, cedula))
        self.cnn.commit()
        n = cur.rowcount
        cur.close()
        return n

    def obtener_cursos(self):
        cur = self.cnn.cursor()
        cur.execute("SELECT idcursos, nom_cur FROM cursos")
        cursos = cur.fetchall()
        cur.close()
        return cursos




