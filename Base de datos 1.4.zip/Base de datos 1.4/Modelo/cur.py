import mysql.connector

class Cursos:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",  
            password="", 
            database="escuela"
        )
        self.cursor = self.conn.cursor()

    def insertar_cursos(self, nombre, docente):
        sql = "INSERT INTO cursos (nom_cur, docente) VALUES (%s, %s)"
        valores = (nombre, docente)
        self.cursor.execute(sql, valores)
        self.conn.commit()

    def modificar_cursos(self, idcursos, nombre, docente):
        sql = "UPDATE cursos SET nom_cur=%s, docente=%s WHERE idcursos=%s"
        valores = (nombre, docente, idcursos)
        self.cursor.execute(sql, valores)
        self.conn.commit()

    def eliminar_cursos(self, idcursos):
        sql = "DELETE FROM cursos WHERE idcursos = %s"
        self.cursor.execute(sql, (idcursos,))
        self.conn.commit()
        return self.cursor.rowcount

    def consulta_cursos(self):
        sql = "SELECT idcursos, nom_cur, docente FROM cursos"
        self.cursor.execute(sql)
        return self.cursor.fetchall()
