# archivo: Modulos/estudiantes_asignados/modelo.py

import mysql.connector

def conectar_db():
    return mysql.connector.connect(host="localhost", user="root", password="", database="escuela")

def obtener_estudiantes_asignados(ci_docente):
    conexion = conectar_db()
    cursor = conexion.cursor()

    cursor.execute("SELECT cursos FROM docentes WHERE Ci = %s", (ci_docente,))
    resultado = cursor.fetchone()

    estudiantes = []

    if resultado:
        id_curso = resultado[0]
        cursor.execute("SELECT cedula, nombre, apellido, tele FROM estudiantes WHERE id_curso = %s", (id_curso,))
        estudiantes = cursor.fetchall()

    conexion.close()
    return estudiantes
