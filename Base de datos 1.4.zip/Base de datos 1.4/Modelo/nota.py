import mysql.connector

class Notas:
    def __init__(self):
        self.cnn = mysql.connector.connect(host="localhost",user="root",password="",database="escuela")

    def __str__(self):
        datos = self.consulta_notasss()
        aux = ""
        for row in datos:
            aux = aux + str(row) + "\n"
        return aux

    def consulta_notasss(self):
        cur = self.cnn.cursor()
        cur.execute("SELECT idnotazzzz,estudiante,nota1,nota2,nota3,notadefinitiva FROM notas")
        datos = cur.fetchall()
        cur.close()
        return datos

    def buscar_notazzzz(self,idnotazzzz):
        cur = self.cnn.cursor()
        sql = "SELECT idnotazzzz,estudiante,nota1,nota2,nota3,notadefinitiva " \
        "FROM notas WHERE idnotazzzz = %s"
        cur.execute(sql,(idnotazzzz,))
        datos = cur.fetchone()
        cur.close()
        return datos

    def insertar_notazzzz(self,idnotazzzz,estudiante,nota1,nota2,nota3,notadefinitiva):
        cur = self.cnn.cursor()
        sql = "INSERT INTO notas (idnotazzzz,estudiante,nota1,nota2,nota3,notadefinitiva) " \
        "VALUES (%s,%s,%s,%s,%s,%s)"
        cur.execute(sql,(idnotazzzz,estudiante,nota1,nota2,nota3,notadefinitiva))
        self.cnn.commit()
        cur.close()
        return cur.rowcount

    def eliminar_notazzzz(self,idnotazzzz):
        cur = self.cnn.cursor()
        sql = "DELETE FROM notas WHERE idnotazzzz = %s"
        cur.execute(sql,(idnotazzzz,))
        n = cur.rowcount
        self.cnn.commit()
        cur.close()
        return n

    def modificar_notazzz(self,idnotazzzz,estudiante,nota1,nota2,nota3,notadefinitiva):
        cur = self.cnn.cursor()
        sql = "UPDATE notas SET estudiante = %s, nota1 = %s, nota2 = %s, nota3 = %s, notadefinitiva = %s WHERE idnotazzzz = %s"
        cur.execute(sql,(estudiante,nota1,nota2,nota3,notadefinitiva,idnotazzzz))
        self.cnn.commit()
        n = cur.rowcount
        cur.close()
        return n
