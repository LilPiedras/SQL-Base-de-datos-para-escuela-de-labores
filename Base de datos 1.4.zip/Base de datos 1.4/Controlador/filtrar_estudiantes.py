

from Modelo.filtrar_estu import obtener_estudiantes_asignados

def cargar_estudiantes_para_docente(ci_docente):
    return obtener_estudiantes_asignados(ci_docente)
