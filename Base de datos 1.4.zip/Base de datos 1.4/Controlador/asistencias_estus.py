def main(root):
    from Vista.Ventana_AsisEstu import Ventana_asisEstu #<----- cambiar al nombre de la ventana de asistencia de estudiantes

    root.configure(bg="white")
    root.title("Asistencia de Estudiantes")
    root.geometry("660x550")

    app = Ventana_asisEstu(master=root) #<----- cambiar al nombre correspondiente
    app.pack(fill="both", expand=True)
