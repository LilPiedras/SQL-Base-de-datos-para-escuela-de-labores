def main(ventana):
    from Vista.ventana_AsisDire import VentanaAsistencia

    # Aseguramos que la ventana tenga un color de fondo claro visible
    ventana.configure(bg="white")
    ventana.title("Asistencia de Director")
    ventana.geometry("660x550")

    # Crear instancia de la interfaz
    vista = VentanaAsistencia(master=ventana)

    # Empaquetar manualmente en caso de que no lo haga internamente
    vista.pack(fill="both", expand=True)
