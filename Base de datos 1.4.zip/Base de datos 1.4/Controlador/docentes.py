def main(ventana):
    from Vista.ventana_docen import Ventana

    # Aseguramos que la ventana tenga un color de fondo claro visible
    ventana.configure(bg="white")
    ventana.title("Registro de Docentes")
    ventana.geometry("780x320")
    vista = Ventana(master=ventana)
    vista.pack(fill="both", expand=True)

