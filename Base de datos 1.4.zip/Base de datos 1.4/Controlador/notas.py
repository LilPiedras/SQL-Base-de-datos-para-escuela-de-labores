def main(ventana):
    from Vista.ventana_notas import Ventana

    # Aseguramos que la ventana tenga un color de fondo claro visible
    ventana.configure(bg="white")
    ventana.title("Notas")
    ventana.geometry("750x400")
    vista = Ventana(master=ventana)
    vista.pack(fill="both", expand=True)