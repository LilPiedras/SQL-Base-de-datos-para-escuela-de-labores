def main(ventana):
    from Vista.ventana_cur import Ventana

    # Aseguramos que la ventana tenga un color de fondo claro visible
    ventana.configure(bg="white")
    ventana.title("Registro de Cursos")
    ventana.geometry("500x250")
    vista = Ventana(master=ventana)
    vista.pack(fill="both", expand=True)

