from tkinter import *
from Vista.ventana_usua import Ventana

def main():
    root = Tk()
    root.wm_title("Usuarios")
    app = Ventana(master=root)
    app.iconbitmap("imagenes/favicon.ico")
    app.mainloop()

if __name__ == "__main__":
    main()