def main(ventana):
    from Vista.ventana_asistencia import VentanaAsistencia
    ventana.configure(bg="white")
    ventana.title("Asistencia de Docentes")
    ventana.geometry("660x550")

    # Crear instancia de la interfaz
    vista = VentanaAsistencia(master=ventana)

    # Empaquetar manualmente en caso de que no lo haga internamente
    vista.pack(fill="both", expand=True)
