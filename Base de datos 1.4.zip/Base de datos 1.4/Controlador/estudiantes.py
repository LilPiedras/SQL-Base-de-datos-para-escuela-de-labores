def main(ventana):
    from Vista.ventana_estu import Ventana

    ventana.configure(bg="white")
    ventana.title("Registro estudiantes")
    ventana.geometry("800x300")
    vista = Ventana(master=ventana)
    vista.pack(fill="both", expand=True)
