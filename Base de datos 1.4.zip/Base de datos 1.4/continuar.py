import tkinter as tk
from tkinter import *
from tkinter import messagebox
import customtkinter as ctk
import subprocess
import mysql.connector
from Controlador.usuarios import main as mostrar_usuarios
ventana = ctk.CTk()
ctk.set_appearance_mode("light")

def conectar_db():
    return mysql.connector.connect(host="localhost", user="root", password="", database="escuela")

def volver_a_interfaz():
    ventana_conti.destroy()
    subprocess.Popen(["python", "interfaz.py"])

def login():
    global usuario_actual
    usuario = entry_usuario.get()
    apellido = entry_apellido.get()
    clave = entry_clave.get()

    conexion = conectar_db()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE nombre = %s AND apellido = %s AND clave = %s", (usuario, apellido, clave))
    resultado = cursor.fetchone()
    conexion.close()

    if resultado:
        usuario_actual = apellido

        if usuario_actual == "Vivas":
            ventana_conti.destroy()
            mostrar_usuarios()
        else:
            messagebox.showinfo("Acceso Restringido", "Acceso permitido solo para el usuario 'Vivas'.")
    else:
        messagebox.showerror("Error", "Credenciales incorrectas")

usuario_actual = ""
ventana_conti = ctk.CTk()
ventana_conti.title("Inicio")
ventana_conti.geometry("520x440")
ventana_conti.configure(fg_color="#572364")

frame_login = ctk.CTkFrame(ventana_conti, fg_color="#D3B8E3")
frame_login.pack(pady=30, padx=20, fill="both", expand=True)

lbl_Titulinho = tk.Label(frame_login, text="Bienvenido", font=("Times New Roman", 18, "bold"), bg="#D3B8E3")
lbl_Titulinho.place(x=180, y=20)

lbl_usuario = tk.Label(frame_login, text="Nombre:", font=("Times New Roman", 12), bg="#D3B8E3")
lbl_usuario.place(x=210, y=60)
entry_usuario = ctk.CTkEntry(frame_login)
entry_usuario.place(x=170, y=90)

lbl_apellido = tk.Label(frame_login, text="Apellido:", font=("Times New Roman", 12), bg="#D3B8E3")
lbl_apellido.place(x=210, y=130)
entry_apellido = ctk.CTkEntry(frame_login)
entry_apellido.place(x=170, y=155)

lbl_seguridad = tk.Label(frame_login, text="Código de Seguridad:", font=("Times New Roman", 12), bg="#D3B8E3")
lbl_seguridad.place(x=170, y=200)
entry_clave = ctk.CTkEntry(frame_login)
entry_clave.place(x=170, y=230)

Gwindolin = ctk.CTkButton(frame_login, text="Iniciar Sesión", command=login, fg_color="#B090C0", font=("Times New Roman", 12), corner_radius=20)
Gwindolin.place(x=170, y=280)

Gwin = ctk.CTkButton(frame_login, text="Volver", command=volver_a_interfaz, fg_color="#B090C0", font=("Times New Roman", 12), corner_radius=20)
Gwin.place(x=170, y=330)

ventana_conti.mainloop()
