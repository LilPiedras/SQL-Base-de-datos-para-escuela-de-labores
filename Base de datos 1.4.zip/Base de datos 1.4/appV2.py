import tkinter as tk
import os
import subprocess
from tkinter import ttk, messagebox, PhotoImage
import customtkinter as ctk
import mysql.connector
from Controlador.estudiantes import main as mostrar_estudiantes
from Controlador.docentes import main as mostrar_docentes
from Controlador.directors import main as mostrar_director
from Controlador.cursos import main as mostrar_cursos
from Controlador.asistencias import main as mostrar_asistencias
from Controlador.asistencias_dire import main as mostrar_asistencia_director
from Controlador.asistencias_estus import main as mostrar_asis_estu
from Controlador.notas import main as mostrar_notas
from Vista.vista_filtrar_estu import main as mostrar_estudiantes_asignados
from Controlador.supervisor import main as mostrar_supervisor

ctk.set_appearance_mode("light")

usuario_actual = ""
ventana_abierta = False  # bandera que controla si existe un Toplevel activo

def conectar_db():
    return mysql.connector.connect(host="localhost", user="root", password="", database="escuela")


def volver_a_interfaz():
    ventana_login.destroy()
    subprocess.Popen(["python", "interfaz.py"])


def volver_a_interfaz_login():
    """Cierra todo y relanza interfaz principal."""
    try:
        ventana_login.destroy()
    except tk.TclError:
        pass
    subprocess.Popen(["python", "interfaz.py"])
    os._exit(0)

# ----------------------------------------------------------------------
# APERTURA DE MÓDULOS (ventanas hijas)
# ----------------------------------------------------------------------

def abrir_modulo(funcion_modulo):
    """Abre un Toplevel que alberga la vista dada. Evita múltiples ventanas
    abiertas a la vez y restablece la bandera cuando la ventana se destruye
    desde cualquier origen (X, botón interno, etc.)."""
    global ventana_abierta

    if ventana_abierta:
        messagebox.showwarning("Ventana abierta", "Debe cerrar la ventana actual antes de abrir otra.")
        return

    ventana_abierta = True
    ventana = tk.Toplevel()
    ventana.title("Módulo")
    ventana.geometry("660x450")
    ventana.resizable(False, False)

    def _reset_flag(event=None):
        """Coloca la bandera en False sólo cuando el Toplevel principal se destruye."""
        global ventana_abierta
        if ventana_abierta and (event is None or event.widget is ventana):
            ventana_abierta = False

    def al_cerrar():
        _reset_flag()
        ventana.destroy()

    ventana.protocol("WM_DELETE_WINDOW", al_cerrar)
    ventana.bind("<Destroy>", _reset_flag)

    # 👉 Esta línea debe estar fuera del método al_cerrar
    funcion_modulo(ventana)

def login():
    global usuario_actual
    usuario = entry_usuario.get()
    apellido = entry_apellido.get()
    contrasena = entry_contraseña.get()

    conexion = conectar_db()
    cursor = conexion.cursor()
    cursor.execute(
        "SELECT id, nombre, apellido, contrasena, ci_docente, clave, rol FROM usuarios WHERE nombre = %s AND apellido = %s AND contrasena = %s",
        (usuario, apellido, contrasena)
    )

    resultado = cursor.fetchone()
    conexion.close()

    if resultado:
        usuario_actual = {
            "id": resultado[0],
            "nombre": resultado[1],
            "apellido": resultado[2],
            "contrasena": resultado[3],
            "ci_docente": resultado[4],
            "clave": resultado[5],
            "rol": resultado[6]
        }
        ventana_login.destroy()
        mostrar_index()
    else:
        messagebox.showerror("Error", "Credenciales incorrectas")

def mostrar_index():
    index = ctk.CTk()
    index.title("Panel Principal")
    index.geometry("600x420")
    index.resizable(False, False)
    index.iconbitmap("imagenes/favicon.ico")
    index.configure(fg_color="#D3B8E3")

    tk.Label(index, text="Escuela de Labores", font=("Times New Roman", 10), bg="#D3B8E3").pack()
    tk.Label(index, text="Doña Flor de Caminos", font=("Times New Roman", 18, "bold"), bg="#D3B8E3").pack(pady=15)

    rol_usuario = usuario_actual.get("rol")

    
    botones_por_rol = {
        "admin": [
            ("Registrar Estudiantes", lambda: abrir_modulo(mostrar_estudiantes)),
            ("Registrar Docentes", lambda: abrir_modulo(mostrar_docentes)),
            ("Asistencia", lambda: abrir_modulo(mostrar_asistencias)),
            ("Administrar cursos", lambda: abrir_modulo(mostrar_cursos)),
        ],
        "docente": [
            ("Agregar Notas", lambda: abrir_modulo(mostrar_notas)),
            ("Asistencia", lambda: abrir_modulo(mostrar_asis_estu)),
            (
                "Filtrar Estudiantes",
                lambda: abrir_modulo(lambda v: mostrar_estudiantes_asignados(v, usuario_actual)),
            ),
        ],
        "su": [
            ("Registrar Docentes", lambda: abrir_modulo(mostrar_docentes)),
            ("Asistencia Docente", lambda: abrir_modulo(mostrar_asistencias)),
            ("Asistencia Director", lambda: abrir_modulo(mostrar_asistencia_director)),
            ("Administrar Director", lambda: abrir_modulo(mostrar_director)),
        ],
        "SuperADMIN": [
            ("Administrar Director", lambda: abrir_modulo(mostrar_director)),
            ("Asistencia Director", lambda: abrir_modulo(mostrar_asistencia_director)),
            ("Administrar Supervisor", lambda: abrir_modulo(mostrar_supervisor)),
        ],
    }

    def _estilo_hover(boton, entrar=True):
        boton.configure(bg_color="#E6D0F3" if entrar else "#B090C0", text_color="black" if entrar else "white")

    for texto, comando in botones_por_rol.get(rol_usuario, []):
        btn = ctk.CTkButton(index, text=texto, command=comando, fg_color="#B090C0", text_color="white", font=("Times New Roman", 12))
        btn.pack(padx=20, pady=10)
        btn.bind("<Enter>", lambda e, b=btn: _estilo_hover(b, True))
        btn.bind("<Leave>", lambda e, b=btn: _estilo_hover(b, False))

    ctk.CTkButton(index, text="Cerrar Sesión", fg_color="#B900C0", text_color="white", font=("Times New Roman", 12),
                  command=lambda: volver_a_interfaz_login() if messagebox.askyesno("Cerrar Sesión", "¿Desea Volver?") else None).pack(padx=20, pady=50)

    index.mainloop()

ventana_login = ctk.CTk()
ventana_login.title("Inicio de Sesión")
ventana_login.geometry("540x420")
ventana_login.resizable(False, False)
ventana_login.configure(fg_color="#572364")
ventana_login.iconbitmap("imagenes/favicon.ico")

frame_login = ctk.CTkFrame(ventana_login, fg_color="#D3B8E3")
frame_login.pack(pady=30, padx=20, fill="both", expand=True)

for txt in ("Escuela de Labores", "Doña Flor de Caminos"):
    tk.Label(frame_login, text=txt, font=("Times New Roman", 18 if "Flor" in txt else 10, "bold" if "Flor" in txt else ""), bg="#D3B8E3").pack(pady=(0, 10) if "Flor" in txt else (0, 0))

etiquetas = ["Nombre:", "Apellido:", "Contraseña:"]
entries = []
for etiqueta in etiquetas:
    tk.Label(frame_login, text=etiqueta, font=("Times New Roman", 12), bg="#D3B8E3").pack()
    ent = ctk.CTkEntry(frame_login, show="*" if "Contraseña" in etiqueta else "")
    ent.pack()
    entries.append(ent)

entry_usuario, entry_apellido, entry_contraseña = entries

ctk.CTkButton(frame_login, text="Iniciar Sesión", command=login, font=("Times New Roman", 12), corner_radius=20).pack(padx=20, pady=10)
ctk.CTkButton(frame_login, text="Volver", command=volver_a_interfaz, fg_color="#B090C0", text_color="white", font=("Times New Roman", 12)).pack(pady=15)

ventana_login.mainloop()
