import customtkinter as ctk
from tkinter import ttk, messagebox
from Modelo.cur import *

class Ventana(ctk.CTkFrame):

    cur = Cursos()

    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack(fill="both", expand=True)
        self.configure(width=550, height=300)
        self.crear_widgets()
        self.LlenaDatos()
        self.HabilitarCajas("disabled")
        self.HabilitarBtnOper("normal")
        self.HabilitarBtnGuardar("disabled")
        self.id = -1
        self.master.protocol("WM_DELETE_WINDOW", self.confirmar_salida)

    def confirmar_salida(self):
        if messagebox.askyesno("Confirmar salida", "¿Estás seguro que deseas cerrar la aplicación?"):
            self.master.destroy()

    def HabilitarCajas(self, estado):
        self.txt_nombre.configure(state=estado)
        self.txt_docente.configure(state=estado)

    def HabilitarBtnOper(self, estado):
        self.Eliminar.configure(state=estado)
        self.Modificar.configure(state=estado)
        self.Nuevo.configure(state=estado)

    def HabilitarBtnGuardar(self, estado):
        self.Guardar.configure(state=estado)
        self.Cancelar.configure(state=estado)

    def LimpiarCajas(self):
        self.txt_nombre.delete(0, "end")
        self.txt_docente.delete(0, "end")

    def LimpiarGrid(self):
        for item in self.grid.get_children():
            self.grid.delete(item)

    def solo_numeros(self, texto):
        return all(c.isdigit() or c in "-." for c in texto)

    def solo_letras(self, texto):
        return all(c.isalpha() or c.isspace() for c in texto)

    def LlenaDatos(self):
        datos = self.cur.consulta_cursos()
        for row in datos:
            self.grid.insert("", "end", text=row[0], values=(row[1], row[2]))
        if len(self.grid.get_children()) > 0:
            self.grid.selection_set(self.grid.get_children()[0])

    def bNuevo(self):
        self.HabilitarCajas("normal")
        self.HabilitarBtnOper("disabled")
        self.HabilitarBtnGuardar("normal")
        self.LimpiarCajas()
        self.txt_nombre.focus()

    def bGuardar(self):
        nombre = self.txt_nombre.get()
        docente = self.txt_docente.get()

        if not nombre or not docente:
            messagebox.showerror("Error de validación", "Todos los campos deben ser completados.")
            return

        if self.id == -1:
            self.cur.insertar_cursos(nombre, docente)
            messagebox.showinfo("Insertar", 'Registro insertado correctamente')
        else:
            self.cur.modificar_cursos(self.id, nombre, docente)
            messagebox.showinfo("Modificar", 'Registro modificado correctamente')
            self.id = -1

        self.LimpiarGrid()
        self.LlenaDatos()
        self.LimpiarCajas()
        self.HabilitarBtnGuardar("disabled")
        self.HabilitarBtnOper("normal")
        self.HabilitarCajas("disabled")

    def bModificar(self):
        selected = self.grid.focus()
        aidi = self.grid.item(selected, 'text')
        if aidi == '':
            messagebox.showwarning("Modificar", 'Debe seleccionar un elemento.')
            self.id = -1
        else:
            self.id = aidi
            valores = self.grid.item(selected, 'values')
            self.HabilitarCajas("normal")
            self.LimpiarCajas()
            self.txt_nombre.insert(0, valores[0])
            self.txt_docente.insert(0, valores[1])
            self.HabilitarBtnOper("disabled")
            self.HabilitarBtnGuardar("normal")
            self.txt_nombre.focus()

    def bEliminar(self):
        selected = self.grid.focus()
        clave = self.grid.item(selected, 'text')
        if clave == '':
            messagebox.showwarning("Eliminar", 'Debe seleccionar un elemento.')
        else:
            valores = self.grid.item(selected, 'values')
            data = f"{clave}, {valores[0]}, {valores[1]}"
            r = messagebox.askquestion("Eliminar", f"¿Seguro que desea eliminar este curso?\n{data}")
            if r == messagebox.YES:
                n = self.cur.eliminar_cursos(clave)
                if n == 1:
                    messagebox.showinfo("Eliminar", 'Registro eliminado correctamente')
                    self.LimpiarGrid()
                    self.LlenaDatos()
                else:
                    messagebox.showinfo("Eliminar", 'No se pudo eliminar el registro')

    def bCancelar(self):
        r = messagebox.askquestion("Cancelar", "¿Seguro que desea cancelar la operación actual?")
        if r == messagebox.YES:
            self.LimpiarCajas()
            self.HabilitarBtnGuardar("disabled")
            self.HabilitarBtnOper("normal")
            self.HabilitarCajas("disabled")

    def crear_widgets(self):
        self.frame1 = ctk.CTkFrame(self, fg_color="#572364", width=90)
        self.frame1.pack(side="left", fill="y")

        self.Nuevo = ctk.CTkButton(self.frame1, text="Nuevo", command=self.bNuevo, fg_color="blue", text_color="white")
        self.Nuevo.pack(pady=(20, 10), padx=10)

        self.Modificar = ctk.CTkButton(self.frame1, text="Modificar", command=self.bModificar, fg_color="blue", text_color="white")
        self.Modificar.pack(pady=10, padx=10)

        self.Eliminar = ctk.CTkButton(self.frame1, text="Eliminar", command=self.bEliminar, fg_color="blue", text_color="white")
        self.Eliminar.pack(pady=10, padx=10)

        self.frame2 = ctk.CTkFrame(self, fg_color="#d3dde3")
        self.frame2.pack(side="left", fill="y", padx=5)

        self.txt_nombre = ctk.CTkEntry(self.frame2, placeholder_text="Nombre del Curso")
        self.txt_nombre.pack(pady=(15, 10), padx=10)

        self.txt_docente = ctk.CTkEntry(self.frame2, placeholder_text="Docente CI")
        self.txt_docente.pack(pady=10, padx=10)

        self.Guardar = ctk.CTkButton(self.frame2, text="Guardar", command=self.bGuardar, fg_color="green", text_color="white")
        self.Guardar.pack(pady=(20, 5), padx=10)

        self.Cancelar = ctk.CTkButton(self.frame2, text="Cancelar", command=self.bCancelar, fg_color="red", text_color="white")
        self.Cancelar.pack(pady=5, padx=10)

        self.frame3 = ctk.CTkFrame(self)
        self.frame3.pack(side="right", fill="both", expand=True, padx=5)

        self.grid = ttk.Treeview(self.frame3, columns=("col1", "col2"))
        self.grid.column("#0", width=50, anchor="center")
        self.grid.column("col1", width=100, anchor="center")
        self.grid.column("col2", width=100, anchor="center")
        self.grid.heading("#0", text="ID")
        self.grid.heading("col1", text="Curso")
        self.grid.heading("col2", text="Docente CI")
        self.grid.pack(side="left", fill="both", expand=True)

        sb = ttk.Scrollbar(self.frame3, orient="vertical", command=self.grid.yview)
        sb.pack(side="right", fill="y")
        self.grid.configure(yscrollcommand=sb.set)
