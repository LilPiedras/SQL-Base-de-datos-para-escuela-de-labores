import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
from Modelo.usua import *

class Ventana(ctk.CTkFrame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack(fill="both", expand=True)
        self.configure(fg_color="#D3B8E3")
        self.usua = Usuarios()
        self.id = -1
        self.crear_widgets()
        self.LlenaDatos()
        self.HabilitarCajas("disabled")
        self.HabilitarBtnOper("normal")
        self.HabilitarBtnGuardar("disabled")

    def HabilitarCajas(self, estado):
        state = "normal" if estado == "normal" else "disabled"
        self.txt_nombre.configure(state=state)
        self.txt_apellido.configure(state=state)
        self.txt_contra.configure(state=state)
        self.txt_rol.configure(state=state)

    def HabilitarBtnOper(self, estado):
        self.btn_nuevo.configure(state=estado)
        self.btn_modificar.configure(state=estado)
        self.btn_eliminar.configure(state=estado)

    def HabilitarBtnGuardar(self, estado):
        self.btn_guardar.configure(state=estado)
        self.btn_cancelar.configure(state=estado)

    def LimpiarCajas(self):
        self.txt_nombre.delete(0, "end")
        self.txt_apellido.delete(0, "end")
        self.txt_contra.delete(0, "end")
        self.txt_rol.delete(0, "end")

    def LimpiarGrid(self):
        for item in self.grid.get_children():
            self.grid.delete(item)

    def LlenaDatos(self):
        self.LimpiarGrid()
        datos = self.usua.consulta_usuarios()
        for row in datos:
            self.grid.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4]))

    def crear_widgets(self):
        
        self.frame1 = ctk.CTkFrame(self, width=120, fg_color="#B090C0")
        self.frame1.pack(side="left", fill="y")

        self.btn_nuevo = ctk.CTkButton(self.frame1, text="Nuevo", command=self.bNuevo)
        self.btn_nuevo.pack(pady=10, padx=10)

        self.btn_modificar = ctk.CTkButton(self.frame1, text="Modificar", command=self.fModificar)
        self.btn_modificar.pack(pady=10, padx=10)

        self.btn_eliminar = ctk.CTkButton(self.frame1, text="Eliminar", command=self.bEliminar)
        self.btn_eliminar.pack(pady=10, padx=10)

        
        self.frame2 = ctk.CTkFrame(self)
        self.frame2.pack(side="left", fill="y", padx=20, pady=20)

        self.txt_nombre = ctk.CTkEntry(self.frame2, placeholder_text="Nombre")
        self.txt_nombre.pack(pady=5)

        self.txt_apellido = ctk.CTkEntry(self.frame2, placeholder_text="Apellido")
        self.txt_apellido.pack(pady=5)

        self.txt_contra = ctk.CTkEntry(self.frame2, placeholder_text="Contraseña", show="*")
        self.txt_contra.pack(pady=5)

        self.txt_rol = ctk.CTkEntry(self.frame2, placeholder_text="Rol de Usuario")
        self.txt_rol.pack(pady=5)

        self.btn_guardar = ctk.CTkButton(self.frame2, text="Guardar", command=self.bGuardar, fg_color="green")
        self.btn_guardar.pack(pady=5)

        self.btn_cancelar = ctk.CTkButton(self.frame2, text="Cancelar", command=self.bCancelar, fg_color="red")
        self.btn_cancelar.pack(pady=5)

        self.frame3 = tk.Frame(self, bg="white")
        self.frame3.pack(side="right", fill="both", expand=True, padx=10, pady=10)

        self.grid = ttk.Treeview(self.frame3, columns=("Nombre", "Apellido", "Contraseña", "Rol"))
        self.grid.heading("#0", text="ID")
        self.grid.heading("Nombre", text="Nombre")
        self.grid.heading("Apellido", text="Apellido")
        self.grid.heading("Contraseña", text="Contraseña")
        self.grid.heading("Rol", text="Rol")

        self.grid.column("#0", width=40, anchor=tk.CENTER)
        for col in ("Nombre", "Apellido", "Contraseña", "Rol"):
            self.grid.column(col, width=100, anchor=tk.CENTER)

        self.grid.pack(side=tk.LEFT, fill=tk.Y)

        sb = tk.Scrollbar(self.frame3, orient=tk.VERTICAL)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.grid.config(yscrollcommand=sb.set)
        sb.config(command=self.grid.yview)

        self.grid['selectmode'] = 'browse'

    def bNuevo(self):
        self.HabilitarCajas("normal")
        self.HabilitarBtnOper("disabled")
        self.HabilitarBtnGuardar("normal")
        self.LimpiarCajas()
        self.txt_nombre.focus()
        self.id = -1

    def bGuardar(self):
        nombre = self.txt_nombre.get().strip()
        apellido = self.txt_apellido.get().strip()
        contrasena = self.txt_contra.get().strip()
        rol = self.txt_rol.get().strip()

        if not nombre or not apellido or not contrasena or not rol:
            messagebox.showerror("Error de validación", "Todos los campos deben ser completados.")
            return

        if self.id == -1:
            self.usua.insertar_usuario(0, nombre, apellido, contrasena, rol)
            messagebox.showinfo("Insertar", "Registro insertado correctamente")
        else:
            self.usua.modificar_usuarios(self.id, nombre, apellido, contrasena, rol)
            messagebox.showinfo("Modificar", "Registro modificado correctamente")
            self.id = -1

        self.LlenaDatos()
        self.LimpiarCajas()
        self.HabilitarBtnGuardar("disabled")
        self.HabilitarBtnOper("normal")
        self.HabilitarCajas("disabled")

    def fModificar(self):
        selected = self.grid.focus()
        aidi = self.grid.item(selected, 'text')

        if not selected or aidi == '':
            messagebox.showwarning("Modificar", "Debe seleccionar un elemento.")
            self.id = -1
            return

        valores = self.grid.item(selected, 'values')
        if len(valores) < 4:
            messagebox.showerror("Error", f"Datos incompletos: {valores}")
            return

        self.id = aidi
        self.HabilitarCajas("normal")
        self.LimpiarCajas()

        self.txt_nombre.insert(0, valores[0])
        self.txt_apellido.insert(0, valores[1])
        self.txt_contra.insert(0, valores[2])
        self.txt_rol.insert(0, valores[3])

        self.HabilitarBtnOper("disabled")
        self.HabilitarBtnGuardar("normal")
        self.txt_nombre.focus()

    def bEliminar(self):
        selected = self.grid.focus()
        clave = self.grid.item(selected, 'text')

        if clave == '':
            messagebox.showwarning("Eliminar", "Debe seleccionar un usuario.")
        else:
            r = messagebox.askquestion("Eliminar", f"¿Seguro que desea eliminar este usuario?\nID: {clave}")
            if r == messagebox.YES:
                n = self.usua.eliminar_usuario(clave)
                if n == 1:
                    messagebox.showinfo("Eliminar", "Registro eliminado correctamente")
                    self.LlenaDatos()
                else:
                    messagebox.showinfo("Eliminar", "No se pudo eliminar el registro")

    def bCancelar(self):
        r = messagebox.askquestion("Cancelar", "¿Desea cancelar la operación actual?")
        if r == messagebox.YES:
            self.LimpiarCajas()
            self.HabilitarBtnGuardar("disabled")
            self.HabilitarBtnOper("normal")
            self.HabilitarCajas("disabled")
