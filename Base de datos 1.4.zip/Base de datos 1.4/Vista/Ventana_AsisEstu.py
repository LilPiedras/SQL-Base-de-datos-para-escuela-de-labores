from tkinter import *
from tkinter import ttk, messagebox
import customtkinter as ctk
from Modelo.asistencia_estu import *
import datetime
from datetime import date, timedelta
from fpdf import FPDF

class Ventana_asisEstu(Frame):

    def __init__(self, master=None):
        super().__init__(master)
        from Modelo.asistencia_estu import Asistencia_Estudiantes
        self.asisEstu = Asistencia_Estudiantes()
        self.pack(fill="both", expand=True)
        self.configure(bg="#EFEAF5")
        self.crear_widgets()
        self.master.protocol("WM_DELETE_WINDOW", self.confirmar_salida)

    def confirmar_salida(self):
        messagebox.askyesno("Confirmar salida", "¿Estás seguro que deseas cerrar la aplicación?")
        self.master.destroy()


    def crear_widgets(self):
        # Etiqueta de nombre y apellido
        self.nombre_apellido_label = Label(self, text="", font=("Arial", 10, "bold"), fg="blue", bg="#EFEAF5")
        self.nombre_apellido_label.place(x=100, y=20)

        Label(self, text="Activos: ").place(x=330, y=20)
        curso_combobox = IntVar()
        curso_des = ttk.Combobox(self, values=["curso","curso1", "curso2"], width=7, state="readonly", textvariable=curso_combobox)
        curso_des.place(x=380, y=20)

        Label(self, text="CI Estudiante:").place(x=10, y=60)
        self.ci_entry = Entry(self)
        self.ci_entry.place(x=100, y=60, width=120)
        self.ci_entry.bind("<FocusOut>", self.mostrar_nombre_apellido)

        Label(self, text="Mes:").place(x=240, y=60)
        self.mes_var = IntVar()
        self.mes_box = ttk.Combobox(self, textvariable=self.mes_var, width=5, state="readonly")
        self.mes_box['values'] = list(range(1, 13))
        self.mes_box.place(x=280, y=60)
        self.mes_var.set(datetime.date.today().month)

        Label(self, text="Año:").place(x=340, y=60)
        self.anio_var = IntVar()
        self.anio_box = ttk.Combobox(self, textvariable=self.anio_var, width=6, state="readonly")
        self.anio_box['values'] = [2025]  # solo 2025
        self.anio_box.place(x=380, y=60)
        self.anio_var.set(2025)

        ctk.CTkButton(self, text="Filtrar", command=self.filtrar_asistencia, fg_color="blue", text_color="white", width=70).place(x=460, y=58)
        ctk.CTkButton(self, text="Filtrar Activos", command=self.filtrar_asistencia, fg_color="blue", text_color="white", width=90).place(x=490, y=20)
        ctk.CTkButton(self, text="Exportar PDF", command=self.exportar_pdf, fg_color="green", text_color="white", width=90).place(x=540, y=58)
        ctk.CTkButton(self, text="Registrar hoy", command=self.registrar_asistencia, fg_color="orange", text_color="white", width=100).place(x=10, y=410)
        ctk.CTkButton(self, text="Cargar datos prueba", command=self.cargar_datos_de_prueba, fg_color="purple", text_color="white", width=130).place(x=120, y=410)

        self.grid = ttk.Treeview(self, columns=("col1", "col2"))
        self.grid.column("#0", width=50, anchor=CENTER)
        self.grid.column("col1", width=150, anchor=CENTER)
        self.grid.column("col2", width=80, anchor=CENTER)

        self.grid.heading("#0", text="Nº", anchor=CENTER)
        self.grid.heading("col1", text="Fecha", anchor=CENTER)
        self.grid.heading("col2", text="Asistencia", anchor=CENTER)

        self.grid.place(x=10, y=100, width=620, height=300)

        # Fecha manual
        Label(self, text="Fecha (dd-mm-aaaa):").place(x=270, y=390)
        self.fecha_entry = Entry(self)
        self.fecha_entry.place(x=410, y=420, width=100)

        # Checkbox de asistencia estudiantes
        self.asistio_var = IntVar()
        self.asistio_check = Checkbutton(self, text="¿Asistió?", variable=self.asistio_var)
        self.asistio_check.place(x=520, y=420)

        # Botón para registrar asistencia de los estudiantes con fecha
        ctk.CTkButton(self, text="Guardar asistencia", command=self.registrar_asistencia_manual, fg_color="brown", text_color="white", width=150).place(x=10, y=470)

    def mostrar_nombre_apellido(self, event=None):
        ci = self.ci_entry.get().strip()
        if not ci.isdigit():
            self.nombre_apellido_label.config(text="")
            return

        try:
            self.asisEstu.cursor.execute("SELECT nombre, apellido FROM estudiantes WHERE cedula = %s", (ci,))
            resultado = self.asisEstu.cursor.fetchone()
            if resultado:
                nombre, apellido = resultado
                self.nombre_apellido_label.config(text=f"{nombre} {apellido}")
            else:
                self.nombre_apellido_label.config(text="Docente no encontrado")
        except Exception:
            self.nombre_apellido_label.config(text="Error al buscar docente")

    def filtrar_asistencia(self):
        for item in self.grid.get_children():
            self.grid.delete(item)

        ci = self.ci_entry.get().strip()
        mes = self.mes_var.get()
        anio = self.anio_var.get()

        if not ci.isdigit() or mes == 0 or anio == 0:
            messagebox.showerror("Error", "Completa todos los campos correctamente.")
            return

        datos = self.asisEstu.obtener_asistencia_por_docente(int(ci), mes, anio)
        print(f"Datos filtrados para CI {ci}:", datos)

        if not datos:
            messagebox.showinfo("Sin resultados", "No hay asistencias registradas para ese CI, mes y año.")
            return

        self.filtrado = datos
        self.estudiante_ci = ci
        self.mes_actual = mes
        self.anio_actual = anio

        for idx, (fecha, presente) in enumerate(datos):
            simbolo = "✅" if presente else "❌"
            self.grid.insert("", END, text=str(idx + 1), values=(fecha.strftime("%d-%m-%Y"), simbolo))

    def exportar_pdf(self):
        if not hasattr(self, 'filtrado') or not self.filtrado:
            messagebox.showwarning("Aviso", "Filtra primero antes de exportar.")
            return

        try:
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=14)

            titulo = f"Asistencia de CI {self.estudiante_ci} - {self.mes_actual:02}/{self.anio_actual}"
            pdf.cell(0, 10, txt=titulo, ln=True, align='C')
            pdf.ln(10)

            pdf.set_font("Arial", size=11, style='B')
            pdf.cell(30, 10, "Nº", 1, 0, 'C')
            pdf.cell(50, 10, "Fecha", 1, 0, 'C')
            pdf.cell(60, 10, "Estado", 1, 1, 'C')

            pdf.set_font("Arial", size=11)
            for idx, (fecha, presente) in enumerate(self.filtrado):
                pdf.cell(30, 10, str(idx + 1), 1, 0, 'C')
                pdf.cell(50, 10, fecha.strftime("%d-%m-%Y"), 1, 0, 'C')
                estado = "Presente" if presente else "Ausente"
                pdf.cell(60, 10, estado, 1, 1, 'C')

            nombre_archivo = f"asistencia_{self.estudiante_ci}_{self.mes_actual:02}_{self.anio_actual}.pdf"
            pdf.output(nombre_archivo)

            messagebox.showinfo("PDF creado", f"PDF guardado como:\n{nombre_archivo}")
        except Exception as e:
            messagebox.showerror("Error al exportar PDF", str(e))

    def registrar_asistencia(self):
        ci = self.ci_entry.get()
        if not ci.isdigit():
            messagebox.showerror("Error", "Debes ingresar un CI válido.")
            return

        respuesta = messagebox.askyesno("Registrar asistencia", "¿El estudiante asistió hoy?")
        presente = respuesta

        try:
            self.asisEstu.registrar_asistencia(int(ci), presente)
            simbolo = "✅" if presente else "❌"
            messagebox.showinfo("Asistencia registrada", f"Asistencia registrada: {simbolo}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo registrar: {str(e)}")

    def registrar_asistencia_manual(self):
        ci = self.ci_entry.get().strip()
        fecha_texto = self.fecha_entry.get().strip()
        asistio = self.asistio_var.get()

        if not ci.isdigit():
            messagebox.showerror("Error", "CI inválido.")
            return

        try:
            fecha = datetime.datetime.strptime(fecha_texto, "%d-%m-%Y").date()
        except ValueError:
            messagebox.showerror("Error", "Fecha inválida. Usa el formato dd-mm-aaaa.")
            return

        try:
            sql = """
                INSERT INTO asistencia_estudiantes (ci_estu, fecha, asis)
                VALUES (%s, %s, %s)
            """
            self.asisEstu.cursor.execute(sql, (int(ci), fecha, bool(asistio)))
            self.asisEstu.conn.commit()

            estado = "Presente" if asistio else "Ausente"
            messagebox.showinfo("Asistencia registrada", f"Registro guardado para {fecha.strftime('%d-%m-%Y')} - {estado}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar: {str(e)}")

    def cargar_datos_de_prueba(self):
        base_fecha = date(2025, 5, 1)
        dias = 5 # Cambia a 30 si quieres el mes completo

        try:
            for i in range(dias):
                dia = base_fecha + timedelta(days=i)
                presente = (i % 2 == 0)
                self.asisEstu.cursor.execute(
                    "INSERT INTO asistencia_estudiantes (ci_estu, fecha, asis) VALUES (%s, %s, %s)",
                    (31680951, dia, presente)
                )

            for i in range(dias):
                dia = base_fecha + timedelta(days=i)
                self.asisEstu.cursor.execute(
                    "INSERT INTO asistencia_estudiantes (ci_estu, fecha, asis) VALUES (%s, %s, %s)",
                    (123123, dia, True)
                )

            self.asisEstu.conn.commit()
            messagebox.showinfo("Éxito", "Datos de prueba cargados correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos: {str(e)}")