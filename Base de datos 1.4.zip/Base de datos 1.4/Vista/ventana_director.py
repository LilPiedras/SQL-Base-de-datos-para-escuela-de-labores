from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from Modelo.director import *

class Ventana(Frame):

    docen = Docentes()

    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.config(width=680, height=320)
        self.pack()
        self.crear_widgets()
        self.LlenaDatos()
        self.HabilitarCajas("disabled")
        self.HabilitarBtnOper("normal")
        self.HabilitarBtnGuardar("disabled")
        self.id = -1
        self.master.protocol("WM_DELETE_WINDOW", self.confirmar_salida)

    def confirmar_salida(self):
        if messagebox.askyesno("Confirmar salida", "¿Estás seguro que deseas cerrar la aplicación?"):
            self.master.event_generate("<<CerrarVentana>>")
            pass

    def HabilitarCajas(self, estado):
        self.CedulaEntry.configure(state=estado)
        self.thungthungthungthungthunSahur.configure(state=estado)
        self.LiriliLarila.configure(state=estado)
        self.TralaleroTralala.configure(state=estado)


    def HabilitarCajas_modificaronly(self, estado):
        self.CedulaEntry.configure(state="disabled")
        self.thungthungthungthungthunSahur.configure(state=estado)
        self.LiriliLarila.configure(state=estado)
        self.TralaleroTralala.configure(state=estado)


    def HabilitarBtnOper(self, estado):

        self.Modificar.configure(state=estado)


    def HabilitarBtnGuardar(self, estado):
        self.Guardar.configure(state=estado)
        self.Cancelar.configure(state=estado)

    def LimpiarCajas(self):
        self.CedulaEntry.delete(0, END)
        self.thungthungthungthungthunSahur.delete(0, END)
        self.LiriliLarila.delete(0, END)
        self.TralaleroTralala.delete(0, END)


    def LimpiarGrid(self):
        for item in self.grid.get_children():
            self.grid.delete(item)

    def LlenaDatos(self):
        datos = self.docen.consulta_director()
        for row in datos:
            self.grid.insert("", END, text=row[0], values=(row[1], row[2], row[3]))

        if len(self.grid.get_children()) > 0:
            self.grid.selection_set(self.grid.get_children()[0])

    def bNuevo(self):
        self.HabilitarCajas("normal")
        self.HabilitarBtnOper("disabled")
        self.HabilitarBtnGuardar("normal")
        self.LimpiarCajas()
        self.CedulaEntry.focus()

    def bGuardar(self):
        ci = self.CedulaEntry.get()
        nombre = self.thungthungthungthungthunSahur.get()
        apellido = self.LiriliLarila.get()
        telefono = self.TralaleroTralala.get()


        if not nombre or not apellido or not telefono:
            messagebox.showerror("Error de validación", "Todos los campos deben ser completados.")
            return

        if self.id == -1:
            self.docen.insertar_estudiante(ci, nombre, apellido, telefono)
            messagebox.showinfo("Insertar", 'Registro insertado correctamente')
        else:
            self.docen.modificar_estudiantes(self.id, nombre, apellido, telefono)
            messagebox.showinfo("Modificar", 'Registro modificado correctamente')
            self.id = -1

        self.LimpiarGrid()
        self.LlenaDatos()
        self.LimpiarCajas()
        self.HabilitarBtnGuardar("disabled")
        self.HabilitarBtnOper("normal")
        self.HabilitarCajas("disabled")

    def bModificar(self):
        selected = self.grid.focus()
        aidi = self.grid.item(selected, 'text')

        if aidi == '':
            messagebox.showwarning("Modificar", 'Debe seleccionar un elemento.')
            self.id = -1
        else:
            self.id = aidi
            self.HabilitarCajas_modificaronly("normal")
            valores = self.grid.item(selected, 'values')
            self.LimpiarCajas()

            self.CedulaEntry.insert(0, aidi)
            if len(valores) > 0:
                self.thungthungthungthungthunSahur.insert(0, valores[0])
            if len(valores) > 1:
                self.LiriliLarila.insert(0, valores[1])
            if len(valores) > 2:
                self.TralaleroTralala.insert(0, valores[2])

            self.HabilitarBtnOper("disabled")
            self.HabilitarBtnGuardar("normal")
            self.thungthungthungthungthunSahur.focus()

    def bCancelar(self):
        r = messagebox.askquestion("Cancelar", "Seguro que desea cancelar la operacion actual?")
        if r == messagebox.YES:
            self.LimpiarCajas()
            self.HabilitarBtnGuardar("disabled")
            self.HabilitarBtnOper("normal")
            self.HabilitarCajas("disabled")

    def solo_numeros(self, texto):
        return all(c.isdigit() or c in "-." for c in texto)

    def solo_letras(self, texto):
        return all(c.isalpha() or c.isspace() for c in texto)

    def crear_widgets(self):
        frame1 = Frame(self, bg="#572364")
        frame1.place(x=0, y=0, width=90, height=319)

        vcmd_num = (self.master.register(self.solo_numeros), '%P')
        vcmd_txt = (self.master.register(self.solo_letras), '%P')


        self.Modificar = Button(frame1, text="Modificar", command=self.bModificar, bg="blue", fg="white")
        self.Modificar.place(x=5, y=100, width=80, height=30)

        frame2 = Frame(self, bg="#d3dde3")
        frame2.place(x=95, y=0, width=150, height=319)

        Label(frame2, text="Codigo:").place(x=3, y=5)
        self.CedulaEntry = Entry(frame2, validate="key", validatecommand=vcmd_num)
        self.CedulaEntry.place(x=3, y=25, width=100, height=20)


        Label(frame2, text="Nombre:").place(x=3, y=55)
        self.thungthungthungthungthunSahur = Entry(frame2, validate="key", validatecommand=vcmd_txt)
        self.thungthungthungthungthunSahur.place(x=3, y=75, width=100, height=20)

        Label(frame2, text="Apellido:").place(x=3, y=105)
        self.LiriliLarila = Entry(frame2, validate="key", validatecommand=vcmd_txt)
        self.LiriliLarila.place(x=3, y=125, width=100, height=20)

        Label(frame2, text="Contraseña").place(x=3, y=155)
        self.TralaleroTralala = Entry(frame2, validate="key", validatecommand=vcmd_num)
        self.TralaleroTralala.place(x=3, y=175, width=100, height=20)

        self.Guardar = Button(frame2, text="Guardar", command=self.bGuardar, bg="green", fg="white")
        self.Guardar.place(x=10, y=255, width=60, height=30)

        self.Cancelar = Button(frame2, text="Cancelar", command=self.bCancelar, bg="red", fg="white")
        self.Cancelar.place(x=80, y=255, width=60, height=30)

        frame3 = Frame(self, bg="white")
        frame3.place(x=247, y=0, width=420, height=319)

        self.grid = ttk.Treeview(frame3, columns=("col1", "col2", "col3"))
        self.grid.column("#0", width=60)
        self.grid.column("col1", width=70, anchor=CENTER)
        self.grid.column("col2", width=90, anchor=CENTER)
        self.grid.column("col3", width=90, anchor=CENTER)
        self.grid.heading("#0", text="Cod", anchor=CENTER)
        self.grid.heading("col1", text="Nombre", anchor=CENTER)
        self.grid.heading("col2", text="Apellido", anchor=CENTER)
        self.grid.heading("col3", text="Contraseña", anchor=CENTER)
        self.grid.pack(side=LEFT, fill=Y)
        sb = Scrollbar(frame3, orient=VERTICAL)
        sb.pack(side=RIGHT, fill=Y)
        self.grid.config(yscrollcommand=sb.set)
        sb.config(command=self.grid.yview)
        self.grid['selectmode'] = 'browse'
