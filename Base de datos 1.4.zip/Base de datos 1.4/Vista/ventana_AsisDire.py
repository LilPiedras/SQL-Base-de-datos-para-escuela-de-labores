from tkinter import *
from tkinter import ttk, messagebox
from Modelo.asistencia_dire import *
import datetime
from datetime import date, timedelta
from fpdf import FPDF

class VentanaAsistencia(Frame):

    def __init__(self, master=None):
        super().__init__(master)
        from Modelo.asistencia_dire import Asistencia
        self.asistencia = Asistencia()
        self.pack(fill="both", expand=True)
        self.configure(bg="#EFEAF5")
        self.crear_widgets()
        self.master.protocol("WM_DELETE_WINDOW", self.confirmar_salida)

    def confirmar_salida(self):
        if messagebox.askyesno("Confirmar salida", "¿Estás seguro que deseas cerrar la aplicación?"):
            self.master.event_generate("<<CerrarVentana>>")

    def crear_widgets(self):
        # Etiqueta de nombre y apellido
        self.nombre_apellido_label = Label(self, text="", font=("Arial", 10, "bold"), fg="blue", bg="#EFEAF5")
        self.nombre_apellido_label.place(x=230, y=20)

        Label(self, text="CI Director:").place(x=10, y=60)
        self.ci_entry = Entry(self)
        self.ci_entry.place(x=100, y=60, width=120)
        self.ci_entry.bind("<FocusOut>", self.mostrar_nombre_apellido)

        Label(self, text="Mes:").place(x=240, y=60)
        self.mes_var = IntVar()
        self.mes_box = ttk.Combobox(self, textvariable=self.mes_var, width=5, state="readonly")
        self.mes_box['values'] = list(range(1, 13))
        self.mes_box.place(x=280, y=60)
        self.mes_var.set(datetime.date.today().month)

        Label(self, text="Año:").place(x=340, y=60)
        self.anio_var = IntVar()
        self.anio_box = ttk.Combobox(self, textvariable=self.anio_var, width=6, state="readonly")
        self.anio_box['values'] = [2025]
        self.anio_box.place(x=380, y=60)
        self.anio_var.set(2025)

        Button(self, text="Filtrar", command=self.filtrar_asistencia, bg="blue", fg="white").place(x=460, y=58, width=70)
        Button(self, text="Exportar PDF", command=self.exportar_pdf, bg="green", fg="white").place(x=540, y=58, width=90)
        Button(self, text="Registrar hoy", command=self.registrar_asistencia, bg="orange", fg="white").place(x=10, y=410, width=100)
        Button(self, text="Cargar datos prueba", command=self.cargar_datos_prueba, bg="purple", fg="white").place(x=120, y=410, width=130)

        self.grid = ttk.Treeview(self, columns=("col1", "col2"))
        self.grid.column("#0", width=50, anchor=CENTER)
        self.grid.column("col1", width=150, anchor=CENTER)
        self.grid.column("col2", width=80, anchor=CENTER)

        self.grid.heading("#0", text="Nº", anchor=CENTER)
        self.grid.heading("col1", text="Fecha", anchor=CENTER)
        self.grid.heading("col2", text="Asistencia", anchor=CENTER)

        self.grid.place(x=10, y=100, width=620, height=300)

        Label(self, text="Fecha (dd-mm-aaaa):").place(x=270, y=440)
        self.fecha_entry = Entry(self)
        self.fecha_entry.place(x=410, y=440, width=100)

        self.asistio_var = IntVar()
        self.asistio_check = Checkbutton(self, text="¿Asistió?", variable=self.asistio_var)
        self.asistio_check.place(x=520, y=440)

        Button(self, text="Guardar asistencia", command=self.registrar_asistencia_manual,
               bg="brown", fg="white").place(x=10, y=470, width=150)

    def mostrar_nombre_apellido(self, event=None):
        ci = self.ci_entry.get().strip()
        if not ci.isdigit():
            self.nombre_apellido_label.config(text="")
            return

        dat = self.asistencia.obtener_director()
        dato = dat[0]
        if int(dato) == int(ci):
            try:
                self.asistencia.cursor.execute("SELECT nombre, apellido FROM docentes WHERE CI = %s", (ci,))
                resultado = self.asistencia.cursor.fetchone()
                if resultado:
                    nombre, apellido = resultado
                    self.nombre_apellido_label.config(text=f"{nombre} {apellido}")
                else:
                    self.nombre_apellido_label.config(text="Director no encontrado")
            except Exception:
                self.nombre_apellido_label.config(text="Error al buscar el Director")

    def filtrar_asistencia(self):
        for item in self.grid.get_children():
            self.grid.delete(item)

        ci = self.ci_entry.get().strip()
        mes = self.mes_var.get()
        anio = self.anio_var.get()

        if not ci.isdigit() or mes == 0 or anio == 0:
            messagebox.showerror("Error", "Completa todos los campos correctamente.")
            return

        dat = self.asistencia.obtener_director()
        dato = dat[0]

        if int(dato) == int(ci):

            datos = self.asistencia.obtener_asistencia_por_docente(int(ci), mes, anio)

            if not datos:
                messagebox.showinfo("Sin resultados", "No hay asistencias registradas para ese CI, mes y año.")
                return

            self.filtrado = datos
            self.docente_ci = ci
            self.mes_actual = mes
            self.anio_actual = anio

            for idx, (fecha, presente) in enumerate(datos):
                simbolo = "✅" if presente else "❌"
                self.grid.insert("", END, text=str(idx + 1), values=(fecha.strftime("%d-%m-%Y"), simbolo))
        else:
            messagebox.showinfo("Alerta", "Verifique si la cedula del director es la correcta")

    def exportar_pdf(self):
        if not hasattr(self, 'filtrado') or not self.filtrado:
            messagebox.showwarning("Aviso", "Filtra primero antes de exportar.")
            return

        try:
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=14)

            nombre_doc = getattr(self, "nombre_completo", "")
            titulo = f"Asistencia de {nombre_doc} (CI {self.docente_ci}) - {self.mes_actual:02}/{self.anio_actual}"

            pdf.cell(0, 10, txt=titulo, ln=True, align='C')
            pdf.ln(10)

            pdf.set_font("Arial", size=11, style='B')
            pdf.cell(30, 10, "Nº", 1, 0, 'C')
            pdf.cell(50, 10, "Fecha", 1, 0, 'C')
            pdf.cell(60, 10, "Estado", 1, 1, 'C')

            pdf.set_font("Arial", size=11)
            for idx, (fecha, presente) in enumerate(self.filtrado):
                pdf.cell(30, 10, str(idx + 1), 1, 0, 'C')
                pdf.cell(50, 10, fecha.strftime("%d-%m-%Y"), 1, 0, 'C')
                estado = "Presente" if presente else "Ausente"
                pdf.cell(60, 10, estado, 1, 1, 'C')

            nombre_archivo = f"asistencia_{self.docente_ci}_{self.mes_actual:02}_{self.anio_actual}.pdf"
            pdf.output(nombre_archivo)

            messagebox.showinfo("PDF creado", f"PDF guardado como:\n{nombre_archivo}")
        except Exception as e:
            messagebox.showerror("Error al exportar PDF", str(e))

    def registrar_asistencia(self):
        ci = self.ci_entry.get()
        if not ci.isdigit():
            messagebox.showerror("Error", "Debes ingresar un CI válido.")
            return

        respuesta = messagebox.askyesno("Registrar asistencia", "¿El docente asistió hoy?")
        presente = respuesta

        try:
            self.asistencia.registrar_asistencia(int(ci), presente)
            simbolo = "✅" if presente else "❌"
            messagebox.showinfo("Asistencia registrada", f"Asistencia registrada: {simbolo}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo registrar: {str(e)}")

    def registrar_asistencia_manual(self):
        ci = self.ci_entry.get().strip()
        fecha_texto = self.fecha_entry.get().strip()
        asistio = self.asistio_var.get()

        if not ci.isdigit():
            messagebox.showerror("Error", "CI inválido.")
            return

        try:
            fecha = datetime.datetime.strptime(fecha_texto, "%d-%m-%Y").date()
        except ValueError:
            messagebox.showerror("Error", "Fecha inválida. Usa el formato dd-mm-aaaa.")
            return

        try:
            sql = """
                INSERT INTO asistencia_docentes (ci_docente, fecha, presente)
                VALUES (%s, %s, %s)
            """
            self.asistencia.cursor.execute(sql, (int(ci), fecha, bool(asistio)))
            self.asistencia.conn.commit()

            estado = "Presente" if asistio else "Ausente"
            messagebox.showinfo("Asistencia registrada", f"Registro guardado para {fecha.strftime('%d-%m-%Y')} - {estado}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar: {str(e)}")

    def cargar_datos_prueba(self):
        base_fecha = date(2025, 5, 1)
        dias = 5

        try:
            for i in range(dias):
                dia = base_fecha + timedelta(days=i)
                presente = (i % 2 == 0)
                self.asistencia.cursor.execute(
                    "INSERT INTO asistencia_docentes (ci_docente, fecha, presente) VALUES (%s, %s, %s)",
                    (11495705, dia, presente)
                )

            for i in range(dias):
                dia = base_fecha + timedelta(days=i)
                self.asistencia.cursor.execute(
                    "INSERT INTO asistencia_docentes (ci_docente, fecha, presente) VALUES (%s, %s, %s)",
                    (10162664, dia, True)
                )

            self.asistencia.conn.commit()
            messagebox.showinfo("Éxito", "Datos de prueba cargados correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos: {str(e)}")
