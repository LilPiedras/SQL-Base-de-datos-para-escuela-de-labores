# archivo: Modulos/estudiantes_asignados/vista.py

import tkinter as tk
from tkinter import ttk, messagebox
from Controlador.filtrar_estudiantes import cargar_estudiantes_para_docente

def main(ventana, usuario):

    ventana.title("Estudiantes Asignados")
    ventana.geometry("600x400")
    ventana.configure(bg="#D3B8E3")

    tk.Label(ventana, text="Estudiantes de mi Curso", font=("Times New Roman", 16, "bold"), bg="#D3B8E3").pack(pady=10)

    frame_tabla = tk.Frame(ventana, bg="#D3B8E3")
    frame_tabla.pack(padx=20, pady=10, fill="both", expand=True)

    tabla = ttk.Treeview(frame_tabla, columns=("cedula", "nombre", "apellido", "telefono"), show="headings")
    tabla.heading("cedula", text="Cédula")
    tabla.heading("nombre", text="Nombre")
    tabla.heading("apellido", text="Apellido")
    tabla.heading("telefono", text="Teléfono")
    tabla.pack(fill="both", expand=True)

    scrollbar = ttk.Scrollbar(frame_tabla, orient="vertical", command=tabla.yview)
    tabla.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    def bloquear_evento(event): return "break"
    tabla.bind("<Double-1>", bloquear_evento)
    tabla.bind("<Key>", bloquear_evento)


    datos = cargar_estudiantes_para_docente(usuario["ci_docente"])
    if datos:
        for fila in datos:
            tabla.insert("", "end", values=fila)
    else:
        tk.Label(ventana, text="No se encontró curso asignado.", bg="#D3B8E3", fg="red").pack()

    def confirmar_cierre():
        if messagebox.askyesno("Cerrar", "¿Desea cerrar esta ventana?"):
            ventana.destroy()
        if hasattr(ventana, "on_close_callback"):
            ventana.on_close_callback()
