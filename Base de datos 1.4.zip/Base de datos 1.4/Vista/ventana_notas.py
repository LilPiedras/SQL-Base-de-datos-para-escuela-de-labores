import customtkinter as ctk
from tkinter import ttk, messagebox, END, VERTICAL, CENTER, Y, RIGHT, LEFT
from Modelo.nota import *


class Ventana(ctk.CTkFrame):
    nota = Notas()

    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.master.title("Registro Notas")
        self.pack(fill="both", expand=True)
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("dark-blue")
        self.id = -1
        self._crear_widgets()
        self._llenar_grid()
        self._habilitar_cajas("disabled")
        self._habilitar_botones_oper("normal")
        self._habilitar_botones_guardar("disabled")
        self.master.protocol("WM_DELETE_WINDOW", self._confirmar_salida)

    @staticmethod
    def _validar_nota(valor: str) -> bool:
        if valor == "":
            return True
        if not valor.isdigit():
            return False
        return 0 <= int(valor) <= 20

    def confirmar_salida(self):
        if messagebox.askyesno("Confirmar salida", "¿Estás seguro que deseas cerrar la aplicación?"):
            self.master.destroy()


    def _habilitar_cajas(self, estado: str):
        for w in (self.txt_estudiante, self.txt_nota1, self.txt_nota2, self.txt_nota3):
            w.configure(state=estado)

    def _habilitar_cajas_modificar_only(self, estado: str):
        for w in (self.txt_estudiante, self.txt_nota1, self.txt_nota2, self.txt_nota3):
            w.configure(state=estado)

    def _habilitar_botones_oper(self, estado: str):
        for b in (self.btn_nuevo, self.btn_modificar, self.btn_eliminar):
            b.configure(state=estado)

    def _habilitar_botones_guardar(self, estado: str):
        for b in (self.btn_guardar, self.btn_cancelar):
            b.configure(state=estado)

    def _limpiar_cajas(self):
        for w in (self.txt_estudiante, self.txt_nota1, self.txt_nota2, self.txt_nota3):
            w.configure(state="normal")
            w.delete(0, END)
        self.txt_notadef.configure(state="normal")
        self.txt_notadef.delete(0, END)
        self.txt_notadef.configure(state="readonly")

    def _limpiar_grid(self):
        for item in self.grid.get_children():
            self.grid.delete(item)

    def _llenar_grid(self):
        for row in self.nota.consulta_notasss():
            self.grid.insert("", END, text=row[0], values=row[1:])

    def _nuevo(self):
        self._habilitar_cajas("normal")
        self._habilitar_botones_oper("disabled")
        self._habilitar_botones_guardar("normal")
        self._limpiar_cajas()
        self.txt_estudiante.focus()

    def _guardar(self):
        estudiante = self.txt_estudiante.get().strip()
        notas = [self.txt_nota1.get().strip(), self.txt_nota2.get().strip(), self.txt_nota3.get().strip()]
        notadef = self.txt_notadef.get().strip()

        if not estudiante or any(n == "" for n in notas):
            messagebox.showerror("Error de validación", "Todos los campos deben ser completados.")
            return

        if self.id == -1:
            self.nota.insertar_notazzzz(0, estudiante, *notas, notadef)
            messagebox.showinfo("Insertar", "Registro insertado correctamente")
        else:
            self.nota.modificar_notazzz(self.id, estudiante, *notas, notadef)
            messagebox.showinfo("Modificar", "Registro modificado correctamente")
            self.id = -1

        self._limpiar_grid()
        self._llenar_grid()
        self._limpiar_cajas()
        self._habilitar_botones_guardar("disabled")
        self._habilitar_botones_oper("normal")
        self._habilitar_cajas("disabled")

    def _modificar(self):
        selected = self.grid.focus()
        self.id = self.grid.item(selected, "text")
        if self.id == "":
            messagebox.showwarning("Modificar", "Debe seleccionar un registro.")
            self.id = -1
            return

        valores = self.grid.item(selected, "values")
        self._habilitar_cajas_modificar_only("normal")
        self._limpiar_cajas()
        self.txt_estudiante.insert(0, valores[0])
        self.txt_nota1.insert(0, valores[1])
        self.txt_nota2.insert(0, valores[2])
        self.txt_nota3.insert(0, valores[3])
        self._calcular_definitiva()
        self._habilitar_botones_oper("disabled")
        self._habilitar_botones_guardar("normal")

    def _eliminar(self):
        selected = self.grid.focus()
        idnota = self.grid.item(selected, "text")
        if idnota == "":
            messagebox.showwarning("Eliminar", "Debe seleccionar un registro.")
            return

        if messagebox.askyesno("Eliminar", f"¿Seguro que desea eliminar este registro?\nID: {idnota}"):
            if self.nota.eliminar_notazzzz(idnota):
                messagebox.showinfo("Eliminar", "Registro eliminado correctamente")
                self._limpiar_grid()
                self._llenar_grid()
            else:
                messagebox.showerror("Eliminar", "No se pudo eliminar el registro")

    def _cancelar(self):
        if messagebox.askyesno("Cancelar", "¿Desea cancelar la operación actual?"):
            self._limpiar_cajas()
            self._habilitar_botones_guardar("disabled")
            self._habilitar_botones_oper("normal")
            self._habilitar_cajas("disabled")
            self.id = -1

    def _calcular_definitiva(self, *_):
        try:
            n1 = float(self.txt_nota1.get())
            n2 = float(self.txt_nota2.get())
            n3 = float(self.txt_nota3.get())
            promedio = round((n1 + n2 + n3) / 3, 2)
            self.txt_notadef.configure(state="normal")
            self.txt_notadef.delete(0, END)
            self.txt_notadef.insert(0, str(promedio))
            self.txt_notadef.configure(state="readonly")
        except ValueError:
            self.txt_notadef.configure(state="normal")
            self.txt_notadef.delete(0, END)
            self.txt_notadef.configure(state="readonly")

    def _crear_widgets(self):
        frame_menu = ctk.CTkFrame(self, width=90, fg_color="#573464")
        frame_menu.pack(side="left", fill="y")

        self.btn_nuevo = ctk.CTkButton(frame_menu, text="Nuevo", command=self._nuevo, fg_color="blue", hover_color="#003cff", width=80, height=30)
        self.btn_nuevo.place(x=5, y=50)

        self.btn_modificar = ctk.CTkButton(frame_menu, text="Modificar", command=self._modificar, fg_color="blue", hover_color="#003cff", width=80, height=30)
        self.btn_modificar.place(x=5, y=100)

        self.btn_eliminar = ctk.CTkButton(frame_menu, text="Eliminar", command=self._eliminar, fg_color="blue", hover_color="#003cff", width=80, height=30)
        self.btn_eliminar.place(x=5, y=150)

        frame_form = ctk.CTkFrame(self, width=150, fg_color="#d3dde3")
        frame_form.pack(side="left", fill="y")

        vcmd = self.register(self._validar_nota)

        ctk.CTkLabel(frame_form, text="Estudiante:").place(x=3, y=5)
        self.txt_estudiante = ctk.CTkEntry(frame_form, width=130)
        self.txt_estudiante.place(x=3, y=25)

        ctk.CTkLabel(frame_form, text="Primera Nota:").place(x=3, y=55)
        self.txt_nota1 = ctk.CTkEntry(frame_form, validate="key", validatecommand=(vcmd, "%P"), width=130)
        self.txt_nota1.place(x=3, y=75)

        ctk.CTkLabel(frame_form, text="Segunda Nota:").place(x=3, y=105)
        self.txt_nota2 = ctk.CTkEntry(frame_form, validate="key", validatecommand=(vcmd, "%P"), width=130)
        self.txt_nota2.place(x=3, y=125)

        ctk.CTkLabel(frame_form, text="Tercera Nota:").place(x=3, y=155)
        self.txt_nota3 = ctk.CTkEntry(frame_form, validate="key", validatecommand=(vcmd, "%P"), width=130)
        self.txt_nota3.place(x=3, y=175)

        ctk.CTkLabel(frame_form, text="Nota Definitiva:").place(x=3, y=205)
        self.txt_notadef = ctk.CTkEntry(frame_form, state="readonly", width=130)
        self.txt_notadef.place(x=3, y=225)

        for widget in (self.txt_nota1, self.txt_nota2, self.txt_nota3):
            widget.bind("<KeyRelease>", self._calcular_definitiva)

        self.btn_guardar = ctk.CTkButton(frame_form, text="Guardar", fg_color="green", hover_color="#009900", command=self._guardar, width=60, height=30)
        self.btn_guardar.place(x=10, y=300)

        self.btn_cancelar = ctk.CTkButton(frame_form, text="Cancelar", fg_color="red", hover_color="#cc0000", command=self._cancelar, width=60, height=30)
        self.btn_cancelar.place(x=80, y=300)

        frame_grid = ctk.CTkFrame(self, fg_color="white")
        frame_grid.pack(side="left", fill="both", expand=True)

        self.grid = ttk.Treeview(frame_grid, columns=("col1", "col2", "col3", "col4", "col5"), show="headings")
        self.grid.column("col1", width=100, anchor=CENTER)
        self.grid.column("col2", width=100, anchor=CENTER)
        self.grid.column("col3", width=100, anchor=CENTER)
        self.grid.column("col4", width=100, anchor=CENTER)
        self.grid.column("col5", width=100, anchor=CENTER)

        self.grid.heading("col1", text="Estudiante", anchor=CENTER)
        self.grid.heading("col2", text="Primera Nota", anchor=CENTER)
        self.grid.heading("col3", text="Segunda Nota", anchor=CENTER)
        self.grid.heading("col4", text="Tercera Nota", anchor=CENTER)
        self.grid.heading("col5", text="N. Definitiva", anchor=CENTER)

        self.grid.pack(side=LEFT, fill=Y)

        scrollbar = ctk.CTkScrollbar(frame_grid, orientation=VERTICAL, command=self.grid.yview)
        scrollbar.pack(side=RIGHT, fill=Y)
        self.grid.configure(yscrollcommand=scrollbar.set)


if __name__ == "__main__":
    root = ctk.CTk()
    Ventana(root)
    root.mainloop()
